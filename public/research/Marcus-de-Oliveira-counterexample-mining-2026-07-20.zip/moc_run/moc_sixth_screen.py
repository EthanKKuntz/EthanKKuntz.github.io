#!/usr/bin/env python3
"""Numerical sixth-order screen on exact quartic-equality varieties.

This is deliberately not an exact certificate.  It samples generators on the
zero sets of the exact paw, K4-e, and K4 quartic dual forms and evaluates the
sixth Taylor coefficient directly from the squared-minor series.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

import numpy as np

import moc_quartic_cone as sparse
import moc_quartic_dense_cone as dense


def convolution(a, b, order: int):
    out = np.zeros(order + 1, dtype=complex)
    for i in range(order + 1):
        for j in range(order + 1 - i):
            out[i + j] += a[i] * b[j]
    return out


def minor_series(u, i_set, j_set, order: int):
    size = len(i_set)
    if size == 0:
        return np.r_[1.0 + 0.0j, np.zeros(order, dtype=complex)]
    out = np.zeros(order + 1, dtype=complex)
    for permutation in itertools.permutations(range(size)):
        inversions = sum(permutation[i] > permutation[j]
                         for i in range(size) for j in range(i + 1, size))
        term = np.r_[1.0 + 0.0j, np.zeros(order, dtype=complex)]
        for i in range(size):
            term = convolution(
                term, u[:, i_set[i], j_set[permutation[i]]], order
            )
        out += (-1 if inversions % 2 else 1) * term
    return out


def minor_vector_coefficient(k, selected_rows, order: int = 6):
    u = np.zeros((order + 1, 4, 4), dtype=complex)
    power = np.eye(4, dtype=complex)
    factorial = 1
    for r in range(order + 1):
        if r:
            power = power @ k
            factorial *= r
        u[r] = power / factorial
    answer = []
    for row in selected_rows:
        i_set, j_set = sparse.ROWS[row]
        determinant = minor_series(u, i_set, j_set, order)
        answer.append(convolution(determinant, determinant.conjugate(), order)[order].real)
    return np.asarray(answer)


def build_generator(values, edges):
    k = np.zeros((4, 4), dtype=complex)
    for value, (i, j) in zip(values, edges):
        k[i, j] = value
        k[j, i] = -value.conjugate()
    return k


def pair_from_name(name: str):
    return int(name[1]), int(name[3])


def set_cycle_phase(values, edges, cycle, desired_phase):
    edge_index = {edge: i for i, edge in enumerate(edges)}
    terms = []
    constant = 0.0
    for i, j in zip(cycle, cycle[1:] + cycle[:1]):
        index = edge_index[tuple(sorted((i, j)))]
        orientation = 1 if i < j else -1
        if orientation < 0:
            constant += math.pi
        terms.append((index, orientation))
    index, orientation = terms[-1]
    known_phase = constant + sum(sign * np.angle(values[i])
                                 for i, sign in terms[:-1])
    phase = (desired_phase - known_phase) / orientation
    values[index] = abs(values[index]) * np.exp(1j * phase)


def equality_sample(graph, ray, rng):
    edges = dense.GRAPH_EDGES[graph["graph"]]
    values = np.exp(rng.normal(scale=0.5, size=len(edges)) +
                    1j * rng.uniform(-math.pi, math.pi, size=len(edges)))
    pattern = np.asarray(ray["primitive_quartic_pattern"])
    names = graph["monomial_order"]
    nonzero = np.flatnonzero(pattern)
    if not len(nonzero):
        return values
    cycles = [i for i in nonzero if names[i].startswith("P")]
    pairs = [i for i in nonzero if names[i].startswith("s") and "^" not in names[i]]
    if not cycles:
        i, j = pair_from_name(names[pairs[0]])
        values[int(rng.choice([i, j]))] = 0.0
        return values
    first, second = [pair_from_name(names[i]) for i in pairs]
    values[second[1]] = (abs(values[first[0]] * values[first[1]]) /
                         abs(values[second[0]]) *
                         np.exp(1j * np.angle(values[second[1]])))
    cycle_column = cycles[0]
    cycle = tuple(int(i) for i in names[cycle_column][1:])
    desired = 0.0 if pattern[cycle_column] < 0 else math.pi
    set_cycle_phase(values, edges, cycle, desired)
    return values


def quartic_monomials(values, edges, names):
    squared = np.abs(values) ** 2
    k = build_generator(values, edges)
    answer = []
    for name in names:
        if "^" in name:
            answer.append(squared[int(name[1])] ** 2)
        elif name.startswith("s"):
            i, j = pair_from_name(name)
            answer.append(squared[i] * squared[j])
        else:
            cycle = tuple(int(i) for i in name[1:])
            product = 1.0 + 0.0j
            for i, j in zip(cycle, cycle[1:] + cycle[:1]):
                product *= k[i, j]
            answer.append(product.real)
    return np.asarray(answer)


def screen_graph(graph, seed: int, samples_per_ray: int):
    name = graph["graph"]
    edges = dense.GRAPH_EDGES[name]
    selected_rows, _, _, quotient_basis, _ = dense.exact_quotient(edges)
    quotient = np.asarray(quotient_basis, dtype=float)
    rng = np.random.default_rng(seed)
    records = []
    for ray_index, ray in enumerate(graph["rays"]):
        sixth = []
        quartic_residuals = []
        pattern = np.asarray(ray["primitive_quartic_pattern"], dtype=float)
        for _ in range(samples_per_ray):
            values = equality_sample(graph, ray, rng)
            k = build_generator(values, edges)
            norm = np.linalg.norm(k)
            if norm:
                k /= norm
                values /= norm
            quartic_residuals.append(float(
                pattern @ quartic_monomials(values, edges, graph["monomial_order"])
            ))
            projected = quotient @ minor_vector_coefficient(k, selected_rows, 6)
            sixth.append(float(np.dot(ray["ray"], projected)))
        values_array = np.asarray(sixth)
        records.append({
            "ray_index": ray_index,
            "quartic_pattern": ray["primitive_quartic_pattern"],
            "samples": samples_per_ray,
            "max_abs_quartic_residual": float(np.max(np.abs(quartic_residuals))),
            "sixth_dual_evaluation": {
                "min": float(np.min(values_array)),
                "median": float(np.median(values_array)),
                "max": float(np.max(values_array)),
            },
        })
    return {"graph": name, "seed": seed, "rays": records}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--certificate", type=Path,
                        default=Path("results_quartic_dense_cone_exact.json"))
    parser.add_argument("--samples", type=int, default=300)
    parser.add_argument("--seed", type=int, default=20260720)
    parser.add_argument("--output", type=Path,
                        default=Path("results_sixth_screen.json"))
    args = parser.parse_args()
    certificate = json.loads(args.certificate.read_text())
    graphs = []
    for index, graph in enumerate(certificate["graphs"]):
        graphs.append(screen_graph(graph, args.seed + 1000 * index, args.samples))
    global_minimum = min(
        ray["sixth_dual_evaluation"]["min"]
        for graph in graphs for ray in graph["rays"]
    )
    result = {
        "description": "sixth-order numerical screen on exact quartic-equality varieties",
        "interpretation": "a materially negative dual evaluation would be a potential outward sixth-order mechanism; values near zero are rounding noise",
        "samples_per_ray": args.samples,
        "graphs": graphs,
        "global_minimum_sixth_dual_evaluation": global_minimum,
    }
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps({"output": str(args.output),
                      "global_minimum": global_minimum}, indent=2))


if __name__ == "__main__":
    main()
