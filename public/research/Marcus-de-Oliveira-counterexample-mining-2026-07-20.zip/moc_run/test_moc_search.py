import unittest

import numpy as np

import moc_search as m


class TestMOCSearch(unittest.TestCase):
    def test_permutation_unitary_is_vertex(self):
        rng = np.random.default_rng(4)
        n = 5
        a = rng.normal(size=n) + 1j * rng.normal(size=n)
        b = rng.normal(size=n) + 1j * rng.normal(size=n)
        p = np.asarray([2, 4, 1, 0, 3])
        u = np.eye(n, dtype=complex)[:, p]
        z = m.determinant_value(a, b, u)
        vv = m.permutation_products(a, b, m.permutations(n))
        self.assertLess(np.min(np.abs(vv - z)), 1e-11)

    def test_three_geometry_methods_agree(self):
        rng = np.random.default_rng(7)
        for n in (3, 4, 5):
            a, b = m.normalize_spectra(
                rng.normal(size=n) + 1j * rng.normal(size=n),
                rng.normal(size=n) + 1j * rng.normal(size=n),
            )
            u = m.haar_unitary(n, rng)
            vv = m.permutation_products(a, b, m.permutations(n))
            z = m.determinant_value(a, b, u)
            g = m.geometry_validation(z, vv)
            self.assertEqual(g["monotone_inside"], g["qhull_inside"])
            self.assertEqual(g["monotone_inside"], g["lp_inside"])
            self.assertAlmostEqual(g["monotone_margin"], g["qhull_margin"], places=10)

    def test_exactly_unitary_families(self):
        rng = np.random.default_rng(9)
        families = [m.drury_unitary(), m.fourier_unitary(5),
                    m.householder_uniform(5), m.rational_cayley_unitary(5, rng)]
        for u in families:
            self.assertLess(np.linalg.norm(u.conj().T @ u - np.eye(len(u))), 2e-12)

    def test_n3_random_control(self):
        result = m.random_survey(3, seed=12, samples=200, family="haar")
        self.assertEqual(result["outside_count"], 0)


if __name__ == "__main__":
    unittest.main()
