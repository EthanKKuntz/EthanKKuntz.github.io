import unittest
from pathlib import Path

import moc_seventh_order as seventh


class SeventhOrderTests(unittest.TestCase):
    def test_joint_even_equality_forces_seventh_vanishing(self):
        root = Path(__file__).parent
        result = seventh.verify_seventh_order(
            root / "results_quartic_dense_cone_exact.json",
            root / "results_sixth_order_exact.json",
        )
        self.assertEqual(
            {graph["graph"]: graph["invariant_basis_rank"]
             for graph in result["interpolated_graphs"]},
            {"paw": 10, "K4-e": 32},
        )
        for graph in result["interpolated_graphs"]:
            for ray in graph["rays"]:
                self.assertIn(
                    ray["joint_equality_certificate"]["type"],
                    {"coordinate_strata_vanishing", "square_equality_substitution",
                     "phase_endpoint_and_singular_strata"},
                )


if __name__ == "__main__":
    unittest.main()
