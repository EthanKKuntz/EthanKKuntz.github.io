import unittest
from pathlib import Path

import moc_eighth_order as eighth


class EighthOrderTests(unittest.TestCase):
    def test_joint_lower_equality_has_nonnegative_eighth_form(self):
        root = Path(__file__).parent
        result = eighth.verify_eighth_order(
            root / "results_quartic_cone_exact.json",
            root / "results_quartic_dense_cone_exact.json",
            root / "results_sixth_order_exact.json",
            root / "results_seventh_order_exact.json",
        )
        self.assertEqual(
            {graph["graph"]: graph["invariant_basis_rank"]
             for graph in result["full_graphs"]},
            {"paw": 39, "K4-e": 101, "C4": 46},
        )
        self.assertEqual(
            result["K4_symmetry_representative"][
                "equality_restricted_invariant_rank"
            ],
            175,
        )
        self.assertEqual(
            result["K4_symmetry_representative"]["S4_orbit_size"], 3
        )


if __name__ == "__main__":
    unittest.main()
