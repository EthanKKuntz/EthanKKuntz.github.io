import unittest
from pathlib import Path

import moc_sixth_order as sixth


class SixthOrderTests(unittest.TestCase):
    def test_quartic_equality_has_nonnegative_sixth_form(self):
        root = Path(__file__).parent
        result = sixth.verify_sixth_order(
            root / "results_quartic_cone_exact.json",
            root / "results_quartic_dense_cone_exact.json",
        )
        self.assertEqual(
            {graph["graph"]: graph["invariant_basis_rank"]
             for graph in result["graphs"]},
            {"paw": 21, "K4-e": 43, "C4": 24, "K4": 84},
        )
        self.assertEqual(sum(len(graph["rays"]) for graph in result["graphs"]), 38)
        for graph in result["graphs"]:
            for ray in graph["rays"]:
                self.assertIn(
                    ray["equality_certificate"]["type"],
                    {"sixth_form_identically_zero", "monomial_zero_branches",
                     "square_equality_substitution", "positive_phase_bound",
                     "long_am_gm_equality_substitution",
                     "edge_collapse_components"},
                )


if __name__ == "__main__":
    unittest.main()
