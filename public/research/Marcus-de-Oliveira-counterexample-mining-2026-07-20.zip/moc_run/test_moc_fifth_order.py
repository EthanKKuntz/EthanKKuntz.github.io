import unittest

import moc_fifth_order as fifth


class FifthOrderTests(unittest.TestCase):
    def test_quartic_equality_forces_fifth_vanishing(self):
        result = fifth.verify_fifth_order()
        self.assertTrue(
            result["K4_odd_order_certificate"][
                "all_dual_rays_inversion_symmetric"
            ]
        )
        for graph in result["interpolated_graphs"]:
            for ray in graph["rays"]:
                self.assertIn(
                    ray["quartic_zero_implies_fifth_zero"]["type"],
                    {"fifth_form_zero", "monomial_divisibility",
                     "am_gm_equality_substitution"},
                )


if __name__ == "__main__":
    unittest.main()
