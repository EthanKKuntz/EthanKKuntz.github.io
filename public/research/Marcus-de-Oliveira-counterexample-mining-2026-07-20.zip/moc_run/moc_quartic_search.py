#!/usr/bin/env python3
"""Quartic boundary attack for the n=4 Marcus--de Oliveira conjecture.

The search constructs spectra for which the identity permutation and the four
transpositions of a 4-cycle lie on one supporting line.  A skew-Hermitian
generator supported on that cycle then has zero outward coefficients through
order three.  We compute the determinant Taylor series exactly to order four
(in floating arithmetic, without finite differences) and maximize its quartic
outward coefficient over cycle magnitudes and the single gauge-invariant phase.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

import numpy as np
from numpy.typing import NDArray
from scipy.optimize import differential_evolution, least_squares, minimize

import moc_search as m


CArray = NDArray[np.complex128]
RArray = NDArray[np.float64]
CYCLE = ((0, 1), (1, 2), (2, 3), (3, 0))


def swap_permutation(n: int, i: int, j: int) -> tuple[int, ...]:
    p = list(range(n))
    p[i], p[j] = p[j], p[i]
    return tuple(p)


def truncated_convolution(x: CArray, y: CArray, order: int) -> CArray:
    out = np.zeros(order + 1, dtype=complex)
    for i in range(order + 1):
        for j in range(order + 1 - i):
            out[i + j] += x[i] * y[j]
    return out


def determinant_series(a: CArray, b: CArray, k: CArray, order: int = 4) -> CArray:
    """Coefficients of det(diag(a)+exp(tK)diag(b)exp(-tK)) through t^order."""
    n = len(a)
    upowers: list[CArray] = []
    vpowers: list[CArray] = []
    kp = np.eye(n, dtype=complex)
    km = np.eye(n, dtype=complex)
    for r in range(order + 1):
        if r:
            kp = kp @ k
            km = km @ (-k)
        upowers.append(kp / math.factorial(r))
        vpowers.append(km / math.factorial(r))

    matrix_series = np.zeros((order + 1, n, n), dtype=complex)
    db = np.diag(b)
    for r in range(order + 1):
        for s in range(r + 1):
            matrix_series[r] += upowers[s] @ db @ vpowers[r - s]
    matrix_series[0] += np.diag(a)

    answer = np.zeros(order + 1, dtype=complex)
    for p in itertools.permutations(range(n)):
        inversions = sum(p[i] > p[j] for i in range(n) for j in range(i + 1, n))
        term = np.zeros(order + 1, dtype=complex)
        term[0] = 1
        for i in range(n):
            term = truncated_convolution(term, matrix_series[:, i, p[i]], order)
        answer += (-1 if inversions % 2 else 1) * term
    return answer


def cycle_generator(x: RArray, floor: float = 0.02) -> tuple[CArray, RArray, float]:
    """Norm-one K on the 4-cycle, modulo diagonal-unitary gauge.

    The first three edge phases are gauged to zero.  x[:3] parametrizes four
    edge weights by a softmax (the fourth logit is zero), and x[3] is the cycle
    phase.  The returned weights sum to one and equal twice the squared edge
    magnitudes, so ||K||_F=1.
    """
    logits = np.r_[x[:3], 0.0]
    logits -= np.max(logits)
    weights = np.exp(logits)
    weights /= np.sum(weights)
    weights = floor + (1.0 - 4.0 * floor) * weights
    phases = (0.0, 0.0, 0.0, float(x[3]))
    k = np.zeros((4, 4), dtype=complex)
    for weight, phase, (i, j) in zip(weights, phases, CYCLE):
        z = math.sqrt(float(weight) / 2.0) * np.exp(1j * phase)
        k[i, j] = z
        k[j, i] = -z.conjugate()
    return k, weights, float(x[3])


def support_gaps(x: RArray, perms: NDArray[np.int64]) -> tuple[RArray, CArray, CArray, float, CArray, float]:
    a, b = m.unpack_spectra(x[:16], 4)
    theta = float(x[16])
    vertices = m.permutation_products(a, b, perms)
    scale = max(1e-12, float(np.sqrt(np.mean(np.abs(vertices) ** 2))))
    scores = np.real(np.exp(-1j * theta) * vertices)
    return (scores - scores[0]) / scale, a, b, theta, vertices, scale


def separation_metrics(a: CArray, b: CArray) -> dict[str, float]:
    da = min(abs(a[i] - a[j]) for i in range(4) for j in range(i + 1, 4))
    db = min(abs(b[i] - b[j]) for i in range(4) for j in range(i + 1, 4))
    diagonal = min(abs(a[i] + b[i]) for i in range(4))
    return {"a_min_pair_distance": float(da), "b_min_pair_distance": float(db),
            "min_abs_a_plus_b": float(diagonal)}


def find_cycle_faces(seed: int, starts: int, keep: int) -> list[dict]:
    rng = np.random.default_rng(seed)
    perms = m.permutations(4)
    pmap = {tuple(p): i for i, p in enumerate(perms)}
    edge_indices = np.asarray([pmap[swap_permutation(4, i, j)] for i, j in CYCLE])
    found: list[dict] = []

    def feasibility_objective(x: RArray) -> float:
        gaps, a, b, _, _, _ = support_gaps(x, perms)
        equalities = float(np.sum(gaps[edge_indices] ** 2))
        outside = float(np.sum(np.maximum(gaps, 0.0) ** 2))
        metrics = separation_metrics(a, b)
        diversity = sum(max(0.0, 0.12 - value) ** 2 for value in metrics.values())
        return 300.0 * equalities + 300.0 * outside + 10.0 * diversity

    for start in range(starts):
        x0 = np.r_[rng.normal(size=16), rng.uniform(-math.pi, math.pi)]
        local = minimize(feasibility_objective, x0, method="L-BFGS-B",
                         options={"maxiter": 3500, "ftol": 1e-15, "gtol": 1e-10})
        x1 = local.x

        # Project the four intended support equalities to numerical precision.
        projection = least_squares(
            lambda x: np.r_[support_gaps(x, perms)[0][edge_indices], 1e-7 * (x - x1)],
            x1, xtol=1e-14, ftol=1e-14, gtol=1e-14, max_nfev=4000,
        )
        x = projection.x
        gaps, a, b, theta, vertices, scale = support_gaps(x, perms)
        metrics = separation_metrics(a, b)
        equality_error = float(np.max(np.abs(gaps[edge_indices])))
        outside_error = float(np.max(gaps))
        if equality_error > 2e-7 or outside_error > 2e-7 or min(metrics.values()) < 0.075:
            continue
        structure_a = m.spectrum_structure(a)
        structure_b = m.spectrum_structure(b)
        active = {0, *(int(i) for i in edge_indices)}
        inactive_max = max(float(gaps[i]) for i in range(len(gaps)) if i not in active)
        # Cocircular/collinear spectra are already proved cases and, numerically,
        # tend to collapse almost the entire polygon onto the support line.  Keep
        # the attack in the genuinely two-dimensional region with an isolated
        # five-vertex supporting face.
        known_region_residual = min(
            structure_a["line_residual"], structure_a["circle_residual"],
            structure_b["line_residual"], structure_b["circle_residual"],
        )
        if inactive_max > -1e-6 or known_region_residual < 1e-2:
            continue
        found.append({
            "start": start, "x": x, "a": a, "b": b, "theta": theta,
            "vertices": vertices, "scale": scale, "gaps": gaps,
            "edge_indices": edge_indices, "equality_error": equality_error,
            "outside_error": outside_error, "separation": metrics,
            "inactive_support_max": inactive_max,
            "structure_a": structure_a, "structure_b": structure_b,
        })
        if len(found) >= keep:
            break
    return found


def quartic_data(face: dict, k: CArray) -> RArray:
    coefficients = determinant_series(face["a"], face["b"], k, 4)
    return np.real(np.exp(-1j * face["theta"]) * coefficients) / face["scale"]


def search_generator(face: dict, rng: np.random.Generator, samples: int,
                     floor: float, de_iters: int) -> dict:
    random_best = None
    random_values = []
    for _ in range(samples):
        weights = rng.dirichlet(np.ones(4))
        # Invert the floor transform and softmax up to the fourth-logit gauge.
        weights = floor + (1.0 - 4.0 * floor) * weights
        raw = (weights - floor) / (1.0 - 4.0 * floor)
        logits = np.log(raw[:3]) - math.log(float(raw[3]))
        x = np.r_[logits, rng.uniform(-math.pi, math.pi)]
        k, actual_weights, phase = cycle_generator(x, floor)
        coefficients = quartic_data(face, k)
        value = float(coefficients[4])
        random_values.append(value)
        if random_best is None or value > random_best[0]:
            random_best = (value, x, coefficients, actual_weights, phase, k)

    def objective(x: RArray) -> float:
        return -float(quartic_data(face, cycle_generator(x, floor)[0])[4])

    de = differential_evolution(
        objective, [(-7.0, 7.0)] * 3 + [(-math.pi, math.pi)],
        seed=int(rng.integers(2**31 - 1)), maxiter=de_iters, popsize=10,
        mutation=(0.5, 1.0), recombination=0.75, tol=1e-9, polish=True,
    )
    k, weights, phase = cycle_generator(de.x, floor)
    coefficients = quartic_data(face, k)
    values = np.asarray(random_values)
    return {
        "random_samples": samples,
        "random_quartic_quantiles": {str(q): float(np.quantile(values, q))
                                      for q in (0.0, 0.01, 0.5, 0.99, 1.0)},
        "optimized_coefficients": coefficients,
        "optimized_weights": weights,
        "optimized_phase": phase,
        "generator": k,
        "optimizer_success": bool(de.success),
        "optimizer_message": str(de.message),
        "optimizer_evaluations": int(de.nfev),
    }


def encode_face(face: dict, attack: dict) -> dict:
    return {
        "start": face["start"],
        "a": m.encode_complex_vector(face["a"]),
        "b": m.encode_complex_vector(face["b"]),
        "theta": face["theta"],
        "support_gaps": face["gaps"].tolist(),
        "cycle_edge_indices": face["edge_indices"].tolist(),
        "equality_error": face["equality_error"],
        "outside_error": face["outside_error"],
        "inactive_support_max": face["inactive_support_max"],
        "separation": face["separation"],
        "structure_a": face["structure_a"],
        "structure_b": face["structure_b"],
        "attack": {
            "random_samples": attack["random_samples"],
            "random_quartic_quantiles": attack["random_quartic_quantiles"],
            "optimized_coefficients": attack["optimized_coefficients"].tolist(),
            "optimized_weights": attack["optimized_weights"].tolist(),
            "optimized_phase": attack["optimized_phase"],
            "generator": m.encode_complex_matrix(attack["generator"]),
            "optimizer_success": attack["optimizer_success"],
            "optimizer_message": attack["optimizer_message"],
            "optimizer_evaluations": attack["optimizer_evaluations"],
        },
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=20260723)
    ap.add_argument("--starts", type=int, default=80)
    ap.add_argument("--keep", type=int, default=20)
    ap.add_argument("--k-samples", type=int, default=2000)
    ap.add_argument("--floor", type=float, default=0.02)
    ap.add_argument("--de-iters", type=int, default=120)
    ap.add_argument("--output", type=Path, default=Path("results_quartic_n4.json"))
    args = ap.parse_args()
    if not 0.0 <= args.floor < 0.25:
        raise ValueError("floor must lie in [0, 1/4)")

    faces = find_cycle_faces(args.seed, args.starts, args.keep)
    rng = np.random.default_rng(args.seed + 1)
    results = []
    for i, face in enumerate(faces):
        attack = search_generator(face, rng, args.k_samples, args.floor, args.de_iters)
        encoded = encode_face(face, attack)
        results.append(encoded)
        print(json.dumps({"face": i + 1, "of": len(faces),
                          "q4": encoded["attack"]["optimized_coefficients"][4]}))

    output = {
        "description": "n=4 quartic search on a common supporting face for a transposition 4-cycle",
        "seed": args.seed,
        "starts": args.starts,
        "faces_found": len(faces),
        "cycle": [list(edge) for edge in CYCLE],
        "generator_edge_weight_floor": args.floor,
        "results": results,
    }
    args.output.write_text(json.dumps(output, indent=2))
    best = max((r["attack"]["optimized_coefficients"][4] for r in results), default=None)
    print(json.dumps({"output": str(args.output), "faces": len(results),
                      "best_quartic_coefficient": best}, indent=2))


if __name__ == "__main__":
    main()
