import unittest

import moc_quartic_dense_cone as dense


class DenseQuarticConeTests(unittest.TestCase):
    def test_exact_dense_certificates(self):
        result = dense.verify_dense_cones()
        by_name = {graph["graph"]: graph for graph in result["graphs"]}
        self.assertEqual(by_name["paw"]["dual_extreme_rays"], 11)
        self.assertEqual(len(by_name["paw"]["quartic_patterns"]), 4)
        self.assertEqual(by_name["K4-e"]["dual_extreme_rays"], 7)
        self.assertEqual(len(by_name["K4-e"]["quartic_patterns"]), 5)
        self.assertEqual(by_name["K4"]["dual_extreme_rays"], 3)
        self.assertEqual(len(by_name["K4"]["quartic_patterns"]), 3)
        for graph in by_name.values():
            self.assertTrue(graph["square_coefficients_vanish"])
            for pattern in graph["quartic_patterns"]:
                self.assertIn(pattern["am_gm_certificate"]["type"],
                              {"identically_zero", "nonnegative_monomials",
                               "two_term_am_gm"})


if __name__ == "__main__":
    unittest.main()
