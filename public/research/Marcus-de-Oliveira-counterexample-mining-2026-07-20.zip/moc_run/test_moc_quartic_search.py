import math
import unittest

import numpy as np
from scipy.linalg import expm

import moc_quartic_search as q
import moc_search as m


class TestMOCQuarticSearch(unittest.TestCase):
    def test_series_matches_second_variation(self):
        rng = np.random.default_rng(73)
        a, b = m.normalize_spectra(
            rng.normal(size=4) + 1j * rng.normal(size=4),
            rng.normal(size=4) + 1j * rng.normal(size=4),
        )
        h = m.hermitian_from_params(rng.normal(size=16), 4)
        k = 1j * h / np.linalg.norm(h)
        coefficients = q.determinant_series(a, b, k)
        base = np.prod(a + b)
        predicted = 0j
        for i in range(4):
            for j in range(i + 1, 4):
                bp = b.copy()
                bp[i], bp[j] = bp[j], bp[i]
                predicted += abs(k[i, j]) ** 2 * (np.prod(a + bp) - base)
        self.assertLess(abs(coefficients[1]), 1e-13)
        self.assertLess(abs(coefficients[2] - predicted), 2e-13)

    def test_series_reconstructs_small_t_determinant(self):
        rng = np.random.default_rng(91)
        a, b = m.normalize_spectra(
            rng.normal(size=4) + 1j * rng.normal(size=4),
            rng.normal(size=4) + 1j * rng.normal(size=4),
        )
        k, weights, _ = q.cycle_generator(rng.normal(size=4), floor=0.02)
        self.assertAlmostEqual(float(np.linalg.norm(k)), 1.0, places=13)
        self.assertAlmostEqual(float(np.sum(weights)), 1.0, places=13)
        coefficients = q.determinant_series(a, b, k)
        t = 1e-3
        reconstructed = sum(coefficients[r] * t**r for r in range(5))
        actual = m.determinant_value(a, b, expm(t * k))
        self.assertLess(abs(actual - reconstructed), 5e-14)


if __name__ == "__main__":
    unittest.main()
