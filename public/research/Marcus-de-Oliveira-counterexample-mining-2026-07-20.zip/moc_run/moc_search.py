#!/usr/bin/env python3
"""Computational search for the Marcus--de Oliveira determinantal conjecture.

The search uses the equivalent support-function formulation

  Re(exp(-i theta) det(A + U B U*))
    <= max_sigma Re(exp(-i theta) prod_i(a_i+b_sigma(i))).

Only NumPy/SciPy are required.  Results are JSON so that every run is
reproducible and candidates can be independently rechecked.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
from numpy.typing import NDArray
from scipy.linalg import expm
from scipy.optimize import differential_evolution, linear_sum_assignment, linprog, minimize
from scipy.spatial import ConvexHull
from scipy.special import logsumexp


CArray = NDArray[np.complex128]
RArray = NDArray[np.float64]


def permutations(n: int) -> NDArray[np.int64]:
    return np.asarray(list(itertools.permutations(range(n))), dtype=np.int64)


def normalize_spectra(a: CArray, b: CArray) -> tuple[CArray, CArray]:
    """Fix shift and positive-scale gauges without changing the question."""
    shift = np.mean(a)
    a = a - shift
    b = b + shift
    scale = math.sqrt(float(np.mean(np.abs(a) ** 2) + np.mean(np.abs(b) ** 2)))
    if scale < 1e-12:
        return a, b
    return a / scale, b / scale


def unpack_spectra(x: RArray, n: int) -> tuple[CArray, CArray]:
    a = x[:n] + 1j * x[n : 2 * n]
    b = x[2 * n : 3 * n] + 1j * x[3 * n : 4 * n]
    return normalize_spectra(a.astype(complex), b.astype(complex))


def pack_spectra(a: CArray, b: CArray) -> RArray:
    return np.r_[a.real, a.imag, b.real, b.imag].astype(float)


def permutation_products(a: CArray, b: CArray, perms: NDArray[np.int64]) -> CArray:
    return np.prod(a[None, :] + b[perms], axis=1)


def determinant_value(a: CArray, b: CArray, u: CArray) -> complex:
    m = np.diag(a) + (u * b[None, :]) @ u.conj().T
    return complex(np.linalg.det(m))


def haar_unitary(n: int, rng: np.random.Generator) -> CArray:
    z = rng.normal(size=(n, n)) + 1j * rng.normal(size=(n, n))
    q, r = np.linalg.qr(z)
    d = np.diag(r)
    phases = np.ones_like(d)
    nz = np.abs(d) > 0
    phases[nz] = d[nz] / np.abs(d[nz])
    return q * phases.conj()[None, :]


def hermitian_from_params(x: RArray, n: int) -> CArray:
    h = np.zeros((n, n), dtype=complex)
    h[np.diag_indices(n)] = x[:n]
    k = n
    for i in range(n):
        for j in range(i + 1, n):
            h[i, j] = x[k] + 1j * x[k + 1]
            h[j, i] = x[k] - 1j * x[k + 1]
            k += 2
    return h


def unitary_from_params(x: RArray, n: int, mode: str = "cayley") -> CArray:
    h = hermitian_from_params(x, n)
    if mode == "exp":
        return expm(1j * h)
    if mode == "cayley":
        eye = np.eye(n, dtype=complex)
        return np.linalg.solve(eye - 0.5j * h, eye + 0.5j * h)
    raise ValueError(mode)


def fourier_unitary(n: int) -> CArray:
    j, k = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
    return np.exp(2j * np.pi * j * k / n) / math.sqrt(n)


def drury_unitary() -> CArray:
    # Algebraic maximizer in Drury's n=4 counterexample to the stronger MVC.
    roots = np.roots([16.0, -8.0, 4.0, -1.0])
    k = float(np.real(roots[np.argmin(np.abs(np.imag(roots))) ]))
    beta = math.sqrt(k)
    alpha = math.sqrt(1.0 - 3.0 * k)
    return np.asarray(
        [[alpha, beta, beta, beta],
         [-beta, alpha, beta, -beta],
         [-beta, -beta, alpha, beta],
         [-beta, beta, -beta, alpha]], dtype=complex)


def householder_uniform(n: int) -> CArray:
    v = np.ones(n, dtype=complex) / math.sqrt(n)
    return np.eye(n, dtype=complex) - 2 * np.outer(v, v.conj())


def block_unitary(n: int, rng: np.random.Generator, noise: float = 0.0) -> CArray:
    sizes = [2, n - 2]
    u = np.zeros((n, n), dtype=complex)
    s = 0
    for m in sizes:
        u[s : s + m, s : s + m] = haar_unitary(m, rng)
        s += m
    if noise:
        h = hermitian_from_params(rng.normal(scale=noise, size=n * n), n)
        u = expm(1j * h) @ u
    return u


def rational_cayley_unitary(n: int, rng: np.random.Generator, bound: int = 2) -> CArray:
    """Cayley transform of a Gaussian-integer Hermitian matrix.

    The returned floating matrix represents an exactly unitary matrix over Q(i):
    (I+iH/2)(I-iH/2)^(-1).  Integer H data can therefore be recovered by
    rounding the inverse Cayley transform if an interesting candidate appears.
    """
    h = np.zeros((n, n), dtype=complex)
    h[np.diag_indices(n)] = rng.integers(-bound, bound + 1, size=n)
    for i in range(n):
        for j in range(i + 1, n):
            z = rng.integers(-bound, bound + 1) + 1j * rng.integers(-bound, bound + 1)
            h[i, j], h[j, i] = z, z.conjugate()
    eye = np.eye(n, dtype=complex)
    return np.linalg.solve(eye - 0.5j * h, eye + 0.5j * h)


def exact_support_gap(z: complex, vertices: CArray, theta: float) -> tuple[float, int]:
    rot = np.exp(-1j * theta)
    vals = np.real(rot * vertices)
    j = int(np.argmax(vals))
    return float(np.real(rot * z) - vals[j]), j


def normalized_gap(z: complex, vertices: CArray, theta: float) -> tuple[float, int, float]:
    gap, j = exact_support_gap(z, vertices, theta)
    scale = max(1e-15, float(np.sqrt(np.mean(np.abs(vertices) ** 2))), abs(z))
    return gap / scale, j, scale


def soft_support_gap(z: complex, vertices: CArray, theta: float, tau: float = 2e-3) -> float:
    rot = np.exp(-1j * theta)
    vals = np.real(rot * vertices)
    scale = max(1e-12, float(np.sqrt(np.mean(np.abs(vertices) ** 2))), abs(z))
    t = tau * scale
    support = t * logsumexp(vals / t)
    return float((np.real(rot * z) - support) / scale)


def monotone_hull(points: CArray, tol: float = 1e-12) -> CArray:
    """Independent planar hull implementation; output is CCW."""
    # Permutation products often coincide mathematically but differ by a few ulps
    # because their factors were multiplied in a different order.  Cluster those
    # copies before the combinatorial hull pass.
    radius = max(1.0, float(np.max(np.abs(points))))
    scaled = np.c_[points.real / radius, points.imag / radius]
    scaled = np.unique(np.round(scaled, decimals=13), axis=0)
    xy = sorted((float(p[0] * radius), float(p[1] * radius)) for p in scaled)
    if len(xy) <= 1:
        return np.asarray([complex(*p) for p in xy], dtype=complex)

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in xy:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= tol:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(xy):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= tol:
            upper.pop()
        upper.append(p)
    hull = lower[:-1] + upper[:-1]
    return np.asarray([x + 1j * y for x, y in hull], dtype=complex)


def polygon_facet_gaps(z: complex, hull: CArray) -> RArray:
    if len(hull) < 3:
        return np.asarray([], dtype=float)
    p = np.asarray([z.real, z.imag])
    out = []
    for a, b in zip(hull, np.roll(hull, -1)):
        av = np.asarray([a.real, a.imag])
        ev = np.asarray([(b - a).real, (b - a).imag])
        # CCW interior is to the left; positive is an outward violation.
        out.append(-(ev[0] * (p[1] - av[1]) - ev[1] * (p[0] - av[0])) / np.linalg.norm(ev))
    return np.asarray(out)


def geometry_validation(z: complex, vertices: CArray) -> dict:
    hull = monotone_hull(vertices)
    facets = polygon_facet_gaps(z, hull)
    monotone_margin = float(np.max(facets)) if len(facets) else float("nan")
    qhull_margin = float("nan")
    qhull_inside = None
    if len(np.unique(np.c_[vertices.real, vertices.imag], axis=0)) >= 3:
        try:
            qh = ConvexHull(np.c_[vertices.real, vertices.imag])
            vals = qh.equations[:, :2] @ np.asarray([z.real, z.imag]) + qh.equations[:, 2]
            qhull_margin = float(np.max(vals / np.linalg.norm(qh.equations[:, :2], axis=1)))
            qhull_inside = bool(np.max(vals) <= 1e-10)
        except Exception:
            pass
    # Feasibility of convex weights is a third, non-hull geometry check.
    ae = np.vstack([np.ones(len(vertices)), vertices.real, vertices.imag])
    be = np.asarray([1.0, z.real, z.imag])
    lp = linprog(np.zeros(len(vertices)), A_eq=ae, b_eq=be, bounds=(0.0, None), method="highs")
    return {
        "hull_vertex_count": int(len(hull)),
        "monotone_margin": monotone_margin,
        "monotone_inside": bool(monotone_margin <= 1e-10),
        "qhull_margin": qhull_margin,
        "qhull_inside": qhull_inside,
        "lp_inside": bool(lp.success),
        "lp_status": int(lp.status),
        "lp_residual": (float(np.max(np.abs(ae @ lp.x - be))) if lp.success else None),
    }


@dataclass
class Candidate:
    n: int
    family: str
    seed: int
    a: list[list[float]]
    b: list[list[float]]
    u: list[list[list[float]]]
    theta: float
    determinant: list[float]
    exact_gap: float
    normalized_gap: float
    scale: float
    active_permutation: list[int]
    unitary_error: float
    structure: dict
    geometry: dict


def encode_complex_vector(x: CArray) -> list[list[float]]:
    return [[float(z.real), float(z.imag)] for z in x]


def encode_complex_matrix(x: CArray) -> list[list[list[float]]]:
    return [[[float(z.real), float(z.imag)] for z in row] for row in x]


def spectrum_structure(x: CArray) -> dict:
    pairwise = [abs(x[i] - x[j]) for i in range(len(x)) for j in range(i + 1, len(x))]
    xy = np.c_[x.real, x.imag]
    centered = xy - np.mean(xy, axis=0)
    sv = np.linalg.svd(centered, compute_uv=False)
    line_residual = float(sv[-1] / max(1e-15, sv[0])) if len(sv) > 1 else 0.0
    design = np.c_[2 * xy[:, 0], 2 * xy[:, 1], np.ones(len(x))]
    target = np.sum(xy * xy, axis=1)
    fit = design @ np.linalg.lstsq(design, target, rcond=None)[0]
    circle_residual = float(np.linalg.norm(fit - target) / max(1e-15, np.linalg.norm(target)))
    return {"minimum_pair_distance": float(min(pairwise)) if pairwise else 0.0,
            "line_residual": line_residual, "circle_residual": circle_residual}


def candidate_structure(a: CArray, b: CArray, u: CArray) -> dict:
    p = np.abs(u) ** 2
    rows, cols = linear_sum_assignment(-p)
    monomial_score = float(np.sum(p[rows, cols]) / len(u))
    entropy = -float(np.sum(np.where(p > 0, p * np.log(p), 0.0))) / (len(u) * math.log(len(u)))
    return {"a": spectrum_structure(a), "b": spectrum_structure(b),
            "unitary_monomial_score": monomial_score,
            "unitary_normalized_row_entropy": entropy}


def make_candidate(n: int, family: str, seed: int, a: CArray, b: CArray,
                   u: CArray, theta: float, perms: NDArray[np.int64]) -> Candidate:
    vertices = permutation_products(a, b, perms)
    z = determinant_value(a, b, u)
    ngap, j, scale = normalized_gap(z, vertices, theta)
    gap, _ = exact_support_gap(z, vertices, theta)
    return Candidate(
        n=n, family=family, seed=seed,
        a=encode_complex_vector(a), b=encode_complex_vector(b),
        u=encode_complex_matrix(u), theta=float(theta),
        determinant=[float(z.real), float(z.imag)],
        exact_gap=float(gap), normalized_gap=float(ngap), scale=float(scale),
        active_permutation=[int(v) for v in perms[j]],
        unitary_error=float(np.linalg.norm(u.conj().T @ u - np.eye(n))),
        structure=candidate_structure(a, b, u),
        geometry=geometry_validation(z, vertices),
    )


def optimize_spectra_for_u(n: int, u: CArray, seed: int, family: str,
                           de_iters: int = 120, popsize: int = 8,
                           polish_iters: int = 1000) -> Candidate:
    perms = permutations(n)
    dim = 4 * n + 1

    def objective(x: RArray) -> float:
        a, b = unpack_spectra(x, n)
        if np.linalg.norm(a) + np.linalg.norm(b) < 1e-10:
            return 1e3
        z = determinant_value(a, b, u)
        verts = permutation_products(a, b, perms)
        return -soft_support_gap(z, verts, x[-1])

    bounds = [(-2.0, 2.0)] * (dim - 1) + [(-math.pi, math.pi)]
    de = differential_evolution(
        objective, bounds=bounds, seed=seed, maxiter=de_iters, popsize=popsize,
        mutation=(0.5, 1.0), recombination=0.75, tol=1e-8,
        updating="immediate", workers=1, polish=False,
    )
    local = minimize(objective, de.x, method="Nelder-Mead",
                     options={"maxiter": polish_iters, "xatol": 1e-10, "fatol": 1e-11})
    x = local.x if local.fun < de.fun else de.x
    a, b = unpack_spectra(x, n)
    return make_candidate(n, family, seed, a, b, u, x[-1], perms)


def optimize_joint(n: int, seed: int, mode: str = "cayley", maxiter: int = 1400,
                   starts: int = 12, robust: bool = True) -> Candidate:
    """Multi-start local optimization over spectra, a full unitary, and direction."""
    rng = np.random.default_rng(seed)
    perms = permutations(n)
    sd = 4 * n
    ud = n * n

    def decode(x: RArray):
        a, b = unpack_spectra(x[:sd], n)
        u = unitary_from_params(x[sd : sd + ud], n, mode)
        return a, b, u, x[-1]

    def objective(x: RArray) -> float:
        a, b, u, theta = decode(x)
        verts = permutation_products(a, b, perms)
        z = determinant_value(a, b, u)
        value = -soft_support_gap(z, verts, theta, tau=1e-3)
        if robust:
            # Equality occurs at monomial U and at collapsed spectra.  Keep this
            # branch in the genuinely mixed, separated region so optimization
            # effort is not spent rediscovering those known boundary cases.
            p = np.abs(u) ** 2
            rows, cols = linear_sum_assignment(-p)
            monomial = float(np.sum(p[rows, cols]) / n)
            da = min(abs(a[i] - a[j]) for i in range(n) for j in range(i + 1, n))
            db = min(abs(b[i] - b[j]) for i in range(n) for j in range(i + 1, n))
            value += 20.0 * max(0.0, monomial - 0.85) ** 2
            value += 10.0 * max(0.0, 0.05 - da) ** 2
            value += 10.0 * max(0.0, 0.05 - db) ** 2
        return value

    best = None
    for _ in range(starts):
        x0 = np.r_[rng.normal(size=sd), rng.normal(scale=0.6, size=ud),
                   rng.uniform(-math.pi, math.pi)]
        # Powell is slow but robust to the nonsmooth max approached by softmax.
        bounds = [(-3.0, 3.0)] * sd + [(-2.5, 2.5)] * ud + [(-math.pi, math.pi)]
        opt = minimize(objective, x0, method="Powell", bounds=bounds,
                       options={"maxiter": maxiter, "xtol": 2e-7, "ftol": 2e-9})
        if best is None or opt.fun < best.fun:
            best = opt
    assert best is not None
    a, b, u, theta = decode(best.x)
    return make_candidate(n, f"joint-{'robust-' if robust else ''}{mode}", seed,
                          a, b, u, theta, perms)


def random_survey(n: int, seed: int, samples: int, family: str = "haar") -> dict:
    rng = np.random.default_rng(seed)
    perms = permutations(n)
    best = None
    outside = 0
    hull_dists = []
    for _ in range(samples):
        a, b = normalize_spectra(
            rng.normal(size=n) + 1j * rng.normal(size=n),
            rng.normal(size=n) + 1j * rng.normal(size=n),
        )
        if family == "haar":
            u = haar_unitary(n, rng)
        elif family == "near-block":
            u = block_unitary(n, rng, noise=0.08)
        else:
            raise ValueError(family)
        verts = permutation_products(a, b, perms)
        z = determinant_value(a, b, u)
        hull = monotone_hull(verts)
        margins = polygon_facet_gaps(z, hull)
        raw = float(np.max(margins))
        scale = max(1e-15, float(np.sqrt(np.mean(np.abs(verts) ** 2))), abs(z))
        ngap = raw / scale
        hull_dists.append(ngap)
        if ngap > 1e-10:
            outside += 1
        if best is None or ngap > best[0]:
            # Outward normal of closest/violated edge supplies theta.
            k = int(np.argmax(margins))
            edge = hull[(k + 1) % len(hull)] - hull[k]
            normal = -1j * edge / abs(edge)
            theta = float(np.angle(normal))
            best = (ngap, make_candidate(n, f"random-{family}", seed, a, b, u, theta, perms))
    arr = np.asarray(hull_dists)
    return {
        "n": n, "seed": seed, "family": family, "samples": samples,
        "outside_count": outside,
        "best": asdict(best[1]),
        "margin_quantiles": {str(q): float(np.quantile(arr, q)) for q in [0, .5, .9, .99, 1]},
    }


def root_survey(n: int, seed: int, samples: int, unitary_family: str = "haar") -> dict:
    """Discrete spectra from 0 and roots of unity, including degeneracies."""
    rng = np.random.default_rng(seed)
    alphabet = np.asarray([0, 1, -1, 1j, -1j,
                           np.exp(2j * np.pi / 3), np.exp(4j * np.pi / 3)], dtype=complex)
    perms = permutations(n)
    best = None
    outside = 0
    skipped = 0
    for _ in range(samples):
        a = rng.choice(alphabet, size=n)
        b = rng.choice(alphabet, size=n)
        a, b = normalize_spectra(a, b)
        if np.linalg.norm(a) + np.linalg.norm(b) < 1e-10:
            skipped += 1
            continue
        if unitary_family == "haar":
            u = haar_unitary(n, rng)
        elif unitary_family == "fourier":
            u = fourier_unitary(n)
        else:
            raise ValueError(unitary_family)
        verts = permutation_products(a, b, perms)
        z = determinant_value(a, b, u)
        hull = monotone_hull(verts)
        margins = polygon_facet_gaps(z, hull)
        if not len(margins):
            skipped += 1
            continue
        raw = float(np.max(margins))
        scale = max(1e-15, float(np.sqrt(np.mean(np.abs(verts) ** 2))), abs(z))
        ngap = raw / scale
        outside += int(ngap > 1e-10)
        if best is None or ngap > best[0]:
            k = int(np.argmax(margins))
            edge = hull[(k + 1) % len(hull)] - hull[k]
            theta = float(np.angle(-1j * edge / abs(edge)))
            best = (ngap, make_candidate(n, f"roots-{unitary_family}", seed, a, b, u, theta, perms))
    return {"n": n, "seed": seed, "family": f"roots-{unitary_family}",
            "samples": samples, "skipped": skipped, "outside_count": outside,
            "best": asdict(best[1]) if best else None}


def rational_survey(n: int, seed: int, samples: int) -> dict:
    """Gaussian-integer spectra and exactly unitary rational Cayley matrices."""
    rng = np.random.default_rng(seed)
    perms = permutations(n)
    best = None
    outside = 0
    for _ in range(samples):
        a = rng.integers(-2, 3, n) + 1j * rng.integers(-2, 3, n)
        b = rng.integers(-2, 3, n) + 1j * rng.integers(-2, 3, n)
        a, b = normalize_spectra(a.astype(complex), b.astype(complex))
        if np.linalg.norm(a) + np.linalg.norm(b) < 1e-10:
            continue
        u = rational_cayley_unitary(n, rng)
        verts = permutation_products(a, b, perms)
        z = determinant_value(a, b, u)
        hull = monotone_hull(verts)
        margins = polygon_facet_gaps(z, hull)
        if not len(margins):
            continue
        raw = float(np.max(margins))
        scale = max(1e-15, float(np.sqrt(np.mean(np.abs(verts) ** 2))), abs(z))
        ngap = raw / scale
        outside += int(ngap > 1e-10)
        if best is None or ngap > best[0]:
            k = int(np.argmax(margins))
            edge = hull[(k + 1) % len(hull)] - hull[k]
            theta = float(np.angle(-1j * edge / abs(edge)))
            best = (ngap, make_candidate(n, "gaussian-rational-cayley", seed,
                                         a, b, u, theta, perms))
    return {"n": n, "seed": seed, "family": "gaussian-rational-cayley",
            "samples": samples, "outside_count": outside,
            "best": asdict(best[1]) if best else None}


def run_suite(args) -> dict:
    started = time.time()
    results = []
    for n in args.dimensions:
        if not args.skip_surveys:
            results.append(random_survey(n, args.seed + 100 * n, args.random_samples, "haar"))
            results.append(random_survey(n, args.seed + 100 * n + 1, args.block_samples, "near-block"))
            results.append(root_survey(n, args.seed + 100 * n + 2, args.root_samples, "haar"))
            results.append(root_survey(n, args.seed + 100 * n + 3, args.root_samples, "fourier"))
            results.append(rational_survey(n, args.seed + 100 * n + 4, args.rational_samples))
        if not args.skip_structured:
            structured = [("fourier", fourier_unitary(n)),
                          ("householder", householder_uniform(n))]
            if n == 4:
                structured.append(("drury", drury_unitary()))
            for j, (name, u) in enumerate(structured):
                c = optimize_spectra_for_u(n, u, args.seed + 1000 * n + j, name,
                                           de_iters=args.de_iters, popsize=args.popsize,
                                           polish_iters=args.polish_iters)
                results.append({"kind": "optimized-structured", "best": asdict(c)})
            rng = np.random.default_rng(args.seed + 9000 * n)
            for j in range(args.haar_optimized):
                u = haar_unitary(n, rng)
                c = optimize_spectra_for_u(n, u, args.seed + 9100 * n + j,
                                           f"optimized-haar-{j}", de_iters=args.de_iters,
                                           popsize=args.popsize, polish_iters=args.polish_iters)
                results.append({"kind": "optimized-fixed-haar", "best": asdict(c)})
        for mode in args.joint_modes:
            c = optimize_joint(n, args.seed + 10000 * n + (0 if mode == "cayley" else 1),
                               mode=mode, maxiter=args.joint_iters, starts=args.joint_starts)
            results.append({"kind": "optimized-joint", "best": asdict(c)})
    return {
        "metadata": {"started_unix": started, "elapsed_seconds": time.time() - started,
                     "numpy": np.__version__, "seed": args.seed},
        "arguments": {k: (str(v) if isinstance(v, Path) else v) for k, v in vars(args).items()},
        "results": results,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dimensions", nargs="+", type=int, default=[4, 5])
    ap.add_argument("--seed", type=int, default=20260720)
    ap.add_argument("--random-samples", type=int, default=10000)
    ap.add_argument("--block-samples", type=int, default=3000)
    ap.add_argument("--root-samples", type=int, default=5000)
    ap.add_argument("--rational-samples", type=int, default=5000)
    ap.add_argument("--de-iters", type=int, default=100)
    ap.add_argument("--popsize", type=int, default=7)
    ap.add_argument("--polish-iters", type=int, default=1200)
    ap.add_argument("--joint-modes", nargs="*", default=["cayley", "exp"])
    ap.add_argument("--joint-iters", type=int, default=800)
    ap.add_argument("--joint-starts", type=int, default=8)
    ap.add_argument("--haar-optimized", type=int, default=4)
    ap.add_argument("--skip-surveys", action="store_true")
    ap.add_argument("--skip-structured", action="store_true")
    ap.add_argument("--output", type=Path, default=Path("moc_results.json"))
    args = ap.parse_args()
    result = run_suite(args)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps({"output": str(args.output), "elapsed_seconds": result["metadata"]["elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
