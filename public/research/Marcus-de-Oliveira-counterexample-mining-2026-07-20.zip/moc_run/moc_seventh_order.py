#!/usr/bin/env python3
"""Exact seventh-order follow-up on the sixth-order equality strata.

Only the paw and K4-e can carry degree-seven diagonal-gauge invariants.  C4 is
bipartite, while every K4 dual ray is invariant under permutation inversion
and therefore annihilates all odd Taylor coefficients.  This script
interpolates the remaining forms over Gaussian rationals and checks their
vanishing on every joint quartic/sixth equality component with exact Laurent
polynomials.
"""

from __future__ import annotations

import argparse
import itertools
import json
from fractions import Fraction
from pathlib import Path

import moc_fifth_order as fifth
import moc_quartic_cone as sparse
import moc_quartic_dense_cone as dense
import moc_sixth_order as sixth


TRIANGLES = ((0, 1, 2), (0, 1, 3))


def seventh_minor_vector(values, edges, selected_rows):
    order = 7
    u = fifth.unitary_series(fifth.generator(values, edges), order)
    answer = []
    for row in selected_rows:
        i_set, j_set = sparse.ROWS[row]
        determinant = fifth.minor_series(u, i_set, j_set, order)
        absolute_square = fifth.convolution(
            determinant, [entry.conjugate() for entry in determinant], order
        )
        assert absolute_square[order].imag == 0
        answer.append(absolute_square[order].real)
    return answer


def descriptors(name, edge_count):
    triangles = TRIANGLES[:1] if name == "paw" else TRIANGLES
    answer = [("sst", pair, triangle)
              for triangle in triangles
              for pair in itertools.combinations_with_replacement(
                  range(edge_count), 2)]
    if name == "K4-e":
        cycle = (0, 2, 1, 3)
        for triangle in triangles:
            answer.append(("tp", triangle, cycle, False))
            answer.append(("tp", triangle, cycle, True))
    return answer


def descriptor_name(item):
    if item[0] == "sst":
        _, pair, triangle = item
        return f"s{pair[0]}s{pair[1]}Re(T{''.join(map(str, triangle))})"
    _, triangle, cycle, conjugate_cycle = item
    p = ("conj(P" if conjugate_cycle else "P") + "".join(map(str, cycle))
    if conjugate_cycle:
        p += ")"
    return f"Re(T{''.join(map(str, triangle))}*{p})"


def feature_values(values, edges, basis):
    k = fifth.generator(values, edges)
    squared = fifth.squared_magnitudes(values)
    answer = []
    for item in basis:
        if item[0] == "sst":
            _, pair, triangle = item
            answer.append(squared[pair[0]] * squared[pair[1]] *
                          sixth.cycle_value(k, triangle).real)
        else:
            _, triangle, cycle, conjugate_cycle = item
            left = sixth.cycle_value(k, triangle)
            right = sixth.cycle_value(k, cycle)
            if conjugate_cycle:
                right = right.conjugate()
            answer.append((left * right).real)
    return answer


def symbolic_features(edges, basis):
    edge_count = len(edges)
    variables = 2 * edge_count
    k = sixth.symbolic_generator(edges)
    s = [sixth.poly_mul(sixth.poly_variable(i, variables),
                        sixth.poly_variable(edge_count + i, variables))
         for i in range(edge_count)]
    answer = []
    for item in basis:
        if item[0] == "sst":
            _, pair, triangle = item
            t = sixth.symbolic_cycle(k, triangle, variables)
            real_t = sixth.poly_scale(
                sixth.poly_add(t, sixth.poly_conjugate(t, edge_count)),
                Fraction(1, 2),
            )
            answer.append(sixth.poly_product(
                [s[pair[0]], s[pair[1]], real_t], variables
            ))
        else:
            _, triangle, cycle, conjugate_cycle = item
            t = sixth.symbolic_cycle(k, triangle, variables)
            p = sixth.symbolic_cycle(k, cycle, variables)
            if conjugate_cycle:
                p = sixth.poly_conjugate(p, edge_count)
            product = sixth.poly_mul(t, p)
            answer.append(sixth.poly_scale(
                sixth.poly_add(product,
                               sixth.poly_conjugate(product, edge_count)),
                Fraction(1, 2),
            ))
    return answer


def independent_system(name, edges, seed):
    raw = descriptors(name, len(edges))
    samples = sixth.gaussian_samples(max(90, 3 * len(raw)), seed)
    raw_rows = [feature_values(sample[:len(edges)], edges, raw)
                for sample in samples]
    _, columns = sparse.rref(raw_rows)
    basis = [raw[i] for i in columns]
    rows = [[row[i] for i in columns] for row in raw_rows]
    _, selected = sparse.rref([list(column) for column in zip(*rows)])
    rank = len(columns)
    assert len(selected) == rank
    validation = [i for i in range(len(samples)) if i not in selected][:10]
    return raw, basis, samples, rows, selected, validation


def paw_components(sixth_certificate):
    if sixth_certificate["type"] == "sixth_form_identically_zero":
        return [()]
    components = []
    for branch in sixth_certificate["branches"]:
        edge = branch["zero_edge"]
        residual = branch["nonnegative_residual"]
        if not residual:
            components.append((edge,))
            continue
        assert len(residual) == 1
        support = [i for i, exponent in
                   enumerate(residual[0]["s_exponents"]) if exponent]
        components += [tuple(sorted({edge, extra})) for extra in support]
    return sorted(set(components))


def paw_certificate(poly, sixth_certificate, edge_count):
    components = paw_components(sixth_certificate)
    for component in components:
        assert not sixth.zero_edges(poly, edge_count, component)
    return {"type": "coordinate_strata_vanishing",
            "components": [{"zero_edges": list(component),
                            "seventh_form": "zero"}
                           for component in components]}


def k4e_certificate(poly, quartic_pattern, sixth_certificate, names, edge_count):
    variables = 2 * edge_count
    z = list(range(edge_count))
    w = list(range(edge_count, 2 * edge_count))
    certificate_type = sixth_certificate["type"]
    if certificate_type == "monomial_zero_branches":
        components = [(branch["zero_edge"],)
                      for branch in sixth_certificate["branches"]]
        for component in components:
            assert not sixth.zero_edges(poly, edge_count, component)
        return {"type": "coordinate_strata_vanishing",
                "components": [{"zero_edges": list(component),
                                "seventh_form": "zero"}
                               for component in components]}

    if certificate_type == "square_equality_substitution":
        substitutions = {
            z[4]: sixth.replacement(variables, (z[2], z[3]), (z[1],)),
            w[4]: sixth.replacement(variables, (w[2], w[3]), (w[1],)),
        }
        assert not sixth.substitute_monomials(poly, substitutions)
        return {"type": "square_equality_substitution",
                "relation": "z1*z4=z2*z3", "seventh_form": "zero"}

    assert certificate_type == "positive_phase_bound"
    cycle_column = names.index("P0213")
    cycle_coefficient = quartic_pattern[cycle_column]
    epsilon = -1 if cycle_coefficient > 0 else 1
    # On singular quartic components, impose sixth equality as well.  Some
    # endpoint formulas retain a positive residual after apparent prefactors
    # cancel their Laurent denominators; the exact sixth certificate records
    # that residual explicitly.
    singular_components = []
    for branch in sixth_certificate["singular_components"]:
        base = tuple(branch["zero_edges"])
        residual = branch["nonnegative_residual"]
        if not residual:
            singular_components.append(base)
            continue
        assert len(residual) == 1
        support = [i for i, exponent in
                   enumerate(residual[0]["s_exponents"]) if exponent]
        singular_components += [tuple(sorted(set(base) | {edge}))
                                for edge in support]
    singular_components = sorted(set(singular_components))
    for component in singular_components:
        assert not sixth.zero_edges(poly, edge_count, component)

    # On the nonzero stratum, sixth-order equality says rho=1 and the phase
    # reaches the endpoint of |Re(w^2)| <= s0.  The following Laurent
    # substitutions encode those relations and the quartic square equality.
    delta = -1 if cycle_coefficient > 0 else 1
    substitutions = {
        w[3]: sixth.replacement(variables, (z[1], w[1]), (z[3],)),
        w[0]: sixth.replacement(variables, (z[0], z[3], z[3]),
                                  (z[1], z[1]), delta),
        w[4]: sixth.replacement(variables, (z[1], w[2]), (z[3],), epsilon),
        z[4]: sixth.replacement(variables, (z[2], z[3]), (z[1],), epsilon),
    }
    assert not sixth.substitute_monomials(poly, substitutions)
    return {
        "type": "phase_endpoint_and_singular_strata",
        "singular_components": [list(component) for component in singular_components],
        "regular_relations": [
            "z1*conj(z2)=epsilon*z3*conj(z4)",
            "|z3/z1|=1",
            "(z0*z3/z1)^2=delta*s0",
        ],
        "epsilon": epsilon,
        "delta": delta,
        "seventh_form": "zero",
    }


def verify_graph(name, dense_graph, sixth_graph, seed):
    edges = dense.GRAPH_EDGES[name]
    selected_rows, _, _, quotient_basis, _ = dense.exact_quotient(edges)
    raw, basis, samples, rows, interpolation, validation = independent_system(
        name, edges, seed
    )
    symbolic = symbolic_features(edges, basis)
    indices = interpolation + validation
    vectors = {index: seventh_minor_vector(samples[index][:len(edges)], edges,
                                             selected_rows)
               for index in indices}
    records = []
    for ray_index, (ray, sixth_ray) in enumerate(zip(dense_graph["rays"],
                                                      sixth_graph["rays"])):
        assert ray["ray"] == sixth_ray["ray"]
        functional = [
            sum(quotient_basis[j][r] * ray["ray"][j]
                for j in range(len(quotient_basis)))
            for r in range(14)
        ]
        evaluations = {
            index: sum(functional[r] * vectors[index][r] for r in range(14))
            for index in indices
        }
        coefficients = fifth.solve_square(
            [rows[index] for index in interpolation],
            [evaluations[index] for index in interpolation],
        )
        assert all(sum(rows[index][j] * coefficients[j]
                       for j in range(len(coefficients))) == evaluations[index]
                   for index in validation)
        poly = sixth.combine_symbolic(coefficients, symbolic)
        quartic_pattern = [Fraction(x) for x in ray["primitive_quartic_pattern"]]
        sixth_certificate = sixth_ray["equality_certificate"]
        if name == "paw":
            certificate = paw_certificate(poly, sixth_certificate, len(edges))
        else:
            certificate = k4e_certificate(
                poly, quartic_pattern, sixth_certificate,
                dense_graph["monomial_order"], len(edges)
            )
        records.append({
            "ray_index": ray_index,
            "ray": ray["ray"],
            "quartic_pattern": [str(x) for x in quartic_pattern],
            "seventh_coefficients": [str(x) for x in coefficients],
            "joint_equality_certificate": certificate,
        })
    return {
        "graph": name,
        "raw_invariant_basis_dimension": len(raw),
        "invariant_basis_rank": len(basis),
        "invariant_basis": [descriptor_name(item) for item in basis],
        "interpolation_samples": len(interpolation),
        "independent_validation_samples": len(validation),
        "arithmetic": "exact Gaussian rationals and exact Laurent polynomials",
        "rays": records,
    }


def verify_seventh_order(dense_path, sixth_path):
    dense_result = json.loads(Path(dense_path).read_text())
    sixth_result = json.loads(Path(sixth_path).read_text())
    dense_by_name = {graph["graph"]: graph for graph in dense_result["graphs"]}
    sixth_by_name = {graph["graph"]: graph for graph in sixth_result["graphs"]}
    graphs = [verify_graph(name, dense_by_name[name], sixth_by_name[name],
                           20260720 + i * 1000)
              for i, name in enumerate(("paw", "K4-e"))]
    return {
        "statement": (
            "for every n=4 exact dual ray, joint quartic and sixth equality "
            "forces the seventh dual form to vanish"
        ),
        "consequence": (
            "the n=4 commuting boundary is non-outward through order seven; "
            "the first unresolved local coefficient is order eight"
        ),
        "basis_completeness": (
            "degree seven decomposes into directed cycle types 3+2+2 and 3+4"
        ),
        "interpolated_graphs": graphs,
        "automatic_graphs": {
            "C4": "bipartite, hence has no odd-degree gauge invariant",
            "K4": "all exact dual rays are inversion-symmetric and annihilate every odd order",
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dense-certificate", type=Path,
                        default=Path("results_quartic_dense_cone_exact.json"))
    parser.add_argument("--sixth-certificate", type=Path,
                        default=Path("results_sixth_order_exact.json"))
    parser.add_argument("--output", type=Path,
                        default=Path("results_seventh_order_exact.json"))
    args = parser.parse_args()
    result = verify_seventh_order(args.dense_certificate, args.sixth_certificate)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps({
        "output": str(args.output),
        "graphs": [{"graph": graph["graph"], "rays": len(graph["rays"]),
                    "raw_dimension": graph["raw_invariant_basis_dimension"],
                    "rank": graph["invariant_basis_rank"]}
                   for graph in result["interpolated_graphs"]],
        "first_unresolved_order": 8,
    }, indent=2))


if __name__ == "__main__":
    main()
