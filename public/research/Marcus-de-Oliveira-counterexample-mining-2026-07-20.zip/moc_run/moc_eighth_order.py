#!/usr/bin/env python3
"""Exact eighth-order certificate for the n=4 commuting boundary.

This continues the quartic, fifth, sixth, and seventh-order certificates.  On
the joint equality strata left by the lower even coefficients, every eighth
dual form is nonnegative.  Complete degree-eight invariant bases are used for
the paw, K4-e, and C4.  For K4, interpolation is performed directly on one
perfect-matching equality variety; S4 symmetry covers the other two rays.

All Taylor coefficients, interpolation, substitutions, and sum-of-squares
identities use exact rational or Gaussian-rational arithmetic.
"""

from __future__ import annotations

import argparse
import itertools
import json
from fractions import Fraction
from pathlib import Path

import moc_fifth_order as fifth
import moc_quartic_cone as sparse
import moc_quartic_dense_cone as dense
import moc_sixth_order as sixth


TRIANGLES = ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3))
CYCLES = dense.HAMILTONIAN_CYCLES


def eighth_minor_vector(values, edges, selected_rows):
    order = 8
    u = fifth.unitary_series(fifth.generator(values, edges), order)
    answer = []
    for row in selected_rows:
        i_set, j_set = sparse.ROWS[row]
        determinant = fifth.minor_series(u, i_set, j_set, order)
        absolute_square = fifth.convolution(
            determinant, [entry.conjugate() for entry in determinant], order
        )
        assert absolute_square[order].imag == 0
        answer.append(absolute_square[order].real)
    return answer


def available_cycles(edges):
    index = {tuple(sorted(edge)) for edge in edges}
    return tuple(cycle for cycle in CYCLES
                 if all(tuple(sorted(edge)) in index
                        for edge in zip(cycle, cycle[1:] + cycle[:1])))


def available_triangles(edges):
    index = {tuple(sorted(edge)) for edge in edges}
    return tuple(triangle for triangle in TRIANGLES
                 if all(tuple(sorted(edge)) in index
                        for edge in zip(triangle, triangle[1:] + triangle[:1])))


def descriptors(edges):
    edge_count = len(edges)
    triangles = available_triangles(edges)
    cycles = available_cycles(edges)
    answer = [("ssss", combo)
              for combo in itertools.combinations_with_replacement(
                  range(edge_count), 4)]
    answer += [("ssp", pair, cycle)
               for cycle in cycles
               for pair in itertools.combinations_with_replacement(
                   range(edge_count), 2)]
    triangle_pairs = [(triangle, triangle, False) for triangle in triangles]
    triangle_pairs += [(a, b, False)
                       for a, b in itertools.combinations(triangles, 2)]
    triangle_pairs += [(a, b, True)
                       for a, b in itertools.combinations(triangles, 2)]
    answer += [("stt", edge, a, b, conjugate_second)
               for edge in range(edge_count)
               for a, b, conjugate_second in triangle_pairs]
    cycle_pairs = [(cycle, cycle, False) for cycle in cycles]
    cycle_pairs += [(a, b, False) for a, b in itertools.combinations(cycles, 2)]
    cycle_pairs += [(a, b, True) for a, b in itertools.combinations(cycles, 2)]
    answer += [("pp", a, b, conjugate_second)
               for a, b, conjugate_second in cycle_pairs]
    return answer


def descriptor_name(item):
    if item[0] == "ssss":
        return "".join(f"s{i}" for i in item[1])
    if item[0] == "ssp":
        pair, cycle = item[1], item[2]
        return f"s{pair[0]}s{pair[1]}Re(P{''.join(map(str, cycle))})"
    left = ("T" if item[0] == "stt" else "P") + "".join(map(str, item[2 if item[0] == "stt" else 1]))
    right_data = item[3 if item[0] == "stt" else 2]
    conjugate = item[4 if item[0] == "stt" else 3]
    right = ("T" if item[0] == "stt" else "P") + "".join(map(str, right_data))
    if conjugate:
        right = f"conj({right})"
    prefix = f"s{item[1]}" if item[0] == "stt" else ""
    return f"{prefix}Re({left}*{right})"


def feature_values(values, edges, basis):
    k = fifth.generator(values, edges)
    squared = fifth.squared_magnitudes(values)
    triangles = {triangle: sixth.cycle_value(k, triangle)
                 for triangle in available_triangles(edges)}
    cycles = {cycle: sixth.cycle_value(k, cycle)
              for cycle in available_cycles(edges)}
    answer = []
    for item in basis:
        if item[0] == "ssss":
            value = Fraction(1)
            for edge in item[1]:
                value *= squared[edge]
        elif item[0] == "ssp":
            pair, cycle = item[1], item[2]
            value = squared[pair[0]] * squared[pair[1]] * cycles[cycle].real
        elif item[0] == "stt":
            _, edge, a, b, conjugate_second = item
            second = triangles[b].conjugate() if conjugate_second else triangles[b]
            value = squared[edge] * (triangles[a] * second).real
        else:
            _, a, b, conjugate_second = item
            second = cycles[b].conjugate() if conjugate_second else cycles[b]
            value = (cycles[a] * second).real
        answer.append(value)
    return answer


def symbolic_features(edges, basis):
    edge_count = len(edges)
    variables = 2 * edge_count
    k = sixth.symbolic_generator(edges)
    s = [sixth.poly_mul(sixth.poly_variable(i, variables),
                        sixth.poly_variable(edge_count + i, variables))
         for i in range(edge_count)]
    triangles = {triangle: sixth.symbolic_cycle(k, triangle, variables)
                 for triangle in available_triangles(edges)}
    cycles = {cycle: sixth.symbolic_cycle(k, cycle, variables)
              for cycle in available_cycles(edges)}

    def real_part(poly):
        return sixth.poly_scale(
            sixth.poly_add(poly, sixth.poly_conjugate(poly, edge_count)),
            Fraction(1, 2),
        )

    answer = []
    for item in basis:
        if item[0] == "ssss":
            value = sixth.poly_product([s[edge] for edge in item[1]], variables)
        elif item[0] == "ssp":
            pair, cycle = item[1], item[2]
            value = sixth.poly_product(
                [s[pair[0]], s[pair[1]], real_part(cycles[cycle])], variables
            )
        elif item[0] == "stt":
            _, edge, a, b, conjugate_second = item
            second = (sixth.poly_conjugate(triangles[b], edge_count)
                      if conjugate_second else triangles[b])
            value = sixth.poly_mul(s[edge], real_part(
                sixth.poly_mul(triangles[a], second)
            ))
        else:
            _, a, b, conjugate_second = item
            second = (sixth.poly_conjugate(cycles[b], edge_count)
                      if conjugate_second else cycles[b])
            value = real_part(sixth.poly_mul(cycles[a], second))
        answer.append(value)
    return answer


def independent_system(edges, seed):
    raw = descriptors(edges)
    samples = sixth.gaussian_samples(max(120, 2 * len(raw) + 10), seed)
    raw_rows = [feature_values(sample[:len(edges)], edges, raw)
                for sample in samples]
    _, columns = sparse.rref(raw_rows)
    basis = [raw[i] for i in columns]
    rows = [[row[i] for i in columns] for row in raw_rows]
    _, selected = sparse.rref([list(column) for column in zip(*rows)])
    assert len(selected) == len(columns)
    validation = [i for i in range(len(samples)) if i not in selected][:10]
    return raw, basis, samples, rows, selected, validation


def interpolate_full_graph(name, graph, lower_graph, seed):
    edges = sparse.CYCLE if name == "C4" else dense.GRAPH_EDGES[name]
    if name == "C4":
        selected_rows, _, _, quotient_basis, _ = sparse.exact_quotient()
    else:
        selected_rows, _, _, quotient_basis, _ = dense.exact_quotient(edges)
    raw, basis, samples, rows, selected, validation = independent_system(edges, seed)
    indices = selected + validation
    vectors = {i: eighth_minor_vector(samples[i][:len(edges)], edges, selected_rows)
               for i in indices}
    symbolic = symbolic_features(edges, basis)
    records = []
    for ray_index, ray in enumerate(graph["rays"]):
        functional = [
            sum(quotient_basis[j][r] * ray["ray"][j]
                for j in range(len(quotient_basis)))
            for r in range(14)
        ]
        evaluations = {i: sum(functional[r] * vectors[i][r] for r in range(14))
                       for i in indices}
        coefficients = fifth.solve_square(
            [rows[i] for i in selected], [evaluations[i] for i in selected]
        )
        assert all(sum(rows[i][j] * coefficients[j] for j in range(len(coefficients)))
                   == evaluations[i] for i in validation)
        poly = sixth.combine_symbolic(coefficients, symbolic)
        lower = lower_graph["rays"][ray_index]["joint_equality_certificate"] \
            if name in ("paw", "K4-e") else \
            lower_graph["rays"][ray_index]["equality_certificate"]
        if name == "paw":
            certificate = paw_certificate(poly, lower, len(edges))
        elif name == "K4-e":
            certificate = k4e_certificate(poly, lower, len(edges))
        else:
            certificate = c4_certificate(poly, lower, len(edges))
        records.append({
            "ray_index": ray_index,
            "ray": ray["ray"],
            "eighth_coefficients": [str(value) for value in coefficients],
            "joint_equality_certificate": certificate,
        })
    return {
        "graph": name,
        "raw_invariant_basis_dimension": len(raw),
        "invariant_basis_rank": len(basis),
        "invariant_basis": [descriptor_name(item) for item in basis],
        "interpolation_samples": len(selected),
        "independent_validation_samples": len(validation),
        "rays": records,
    }


def paw_certificate(poly, lower, edge_count):
    components = [tuple(component["zero_edges"]) for component in lower["components"]]
    if components != [()]:
        for component in components:
            assert not sixth.zero_edges(poly, edge_count, component)
        return {"type": "joint_coordinate_strata_vanishing",
                "components": [list(component) for component in components],
                "eighth_form": "zero"}

    variables = 2 * edge_count
    k = sixth.symbolic_generator(dense.GRAPH_EDGES["paw"])
    s = [sixth.poly_mul(sixth.poly_variable(i, variables),
                        sixth.poly_variable(edge_count + i, variables))
         for i in range(edge_count)]
    t = sixth.symbolic_cycle(k, (0, 1, 2), variables)
    real_t_squared = sixth.poly_scale(
        sixth.poly_add(sixth.poly_mul(t, t),
                       sixth.poly_conjugate(sixth.poly_mul(t, t), edge_count)),
        Fraction(1, 2),
    )
    bracket = sixth.poly_add(
        sixth.poly_mul(s[3], sixth.poly_add(sixth.poly_mul(s[0], s[0]),
                                            sixth.poly_mul(s[1], s[1]))),
        sixth.poly_scale(real_t_squared, 2),
    )
    expected = sixth.poly_scale(sixth.poly_mul(s[2], bracket), Fraction(1, 144))
    assert poly == expected
    return {
        "type": "paw_sum_of_squares",
        "eighth_form": "s2*(s3*(s0-s1)^2+4*Re(T012)^2)/144",
        "nonnegative": True,
    }


def k4e_certificate(poly, lower, edge_count):
    variables = 2 * edge_count
    z = list(range(edge_count))
    w = list(range(edge_count, 2 * edge_count))
    kind = lower["type"]
    if kind == "coordinate_strata_vanishing":
        branches = []
        for component in lower["components"]:
            reduced = sixth.zero_edges(poly, edge_count, component["zero_edges"])
            try:
                residual = {"type": "nonnegative_s_monomials", "terms":
                            sixth.nonnegative_s_polynomial(reduced, edge_count)}
            except AssertionError:
                residual = hermitian_binomial_certificate(reduced, edge_count)
            branches.append({"zero_edges": component["zero_edges"],
                             "nonnegative_residual": residual})
        return {"type": "coordinate_strata_nonnegative", "branches": branches}
    if kind == "square_equality_substitution":
        substitutions = {
            z[4]: sixth.replacement(variables, (z[2], z[3]), (z[1],)),
            w[4]: sixth.replacement(variables, (w[2], w[3]), (w[1],)),
        }
        assert not sixth.substitute_monomials(poly, substitutions)
        return {"type": "square_equality_substitution", "eighth_form": "zero"}

    assert kind == "phase_endpoint_and_singular_strata"
    for component in lower["singular_components"]:
        assert not sixth.zero_edges(poly, edge_count, component)
    epsilon, delta = lower["epsilon"], lower["delta"]
    substitutions = {
        w[3]: sixth.replacement(variables, (z[1], w[1]), (z[3],)),
        w[0]: sixth.replacement(variables, (z[0], z[3], z[3]),
                                  (z[1], z[1]), delta),
        w[4]: sixth.replacement(variables, (z[1], w[2]), (z[3],), epsilon),
        z[4]: sixth.replacement(variables, (z[2], z[3]), (z[1],), epsilon),
    }
    assert not sixth.substitute_monomials(poly, substitutions)
    return {"type": "phase_endpoint_and_singular_strata",
            "eighth_form": "zero"}


def hermitian_binomial_certificate(poly, edge_count):
    """Recognize c(D1+D2+X+conj(X)), |X|^2=D1*D2."""
    balanced = [(monomial, coefficient) for monomial, coefficient in poly.items()
                if monomial[:edge_count] == monomial[edge_count:]]
    cross = [(monomial, coefficient) for monomial, coefficient in poly.items()
             if monomial[:edge_count] != monomial[edge_count:]]
    assert len(balanced) == len(cross) == 2
    coefficient = balanced[0][1]
    assert coefficient > 0 and all(value == coefficient
                                   for _, value in balanced + cross)
    first_cross = cross[0][0]
    assert cross[1][0] == (first_cross[edge_count:] +
                           first_cross[:edge_count])
    diagonal_product = tuple(a + b for a, b in
                             zip(balanced[0][0], balanced[1][0]))
    cross_product = tuple(a + b for a, b in
                          zip(cross[0][0], cross[1][0]))
    assert diagonal_product == cross_product
    return {
        "type": "two_term_modulus_square",
        "coefficient": str(coefficient),
        "identity": "c*(D1+D2+2*Re(X)), with |X|^2=D1*D2",
        "nonnegative": True,
    }


def s_laurent(poly, edge_count):
    answer = {}
    for monomial, coefficient in poly.items():
        assert monomial[:edge_count] == monomial[edge_count:]
        exponent = monomial[:edge_count]
        answer[exponent] = answer.get(exponent, Fraction(0)) + coefficient
    return sixth.poly_clean(answer)


def laurent_mul(a, b):
    return sixth.poly_mul(a, b)


def c4_square_certificate(poly):
    reduced = s_laurent(poly, 4)
    if not reduced:
        return None
    variables = 4
    for center in range(4):
        for a, b in itertools.combinations([i for i in range(4) if i != center], 2):
            base = sixth.poly_add(
                sixth.poly_mul(sixth.poly_variable(center, variables),
                               sixth.poly_variable(center, variables)),
                sixth.poly_scale(sixth.poly_mul(sixth.poly_variable(center, variables),
                                                sixth.poly_variable(a, variables)), -1),
                sixth.poly_scale(sixth.poly_mul(sixth.poly_variable(center, variables),
                                                sixth.poly_variable(b, variables)), -1),
                sixth.poly_mul(sixth.poly_variable(a, variables),
                               sixth.poly_variable(b, variables)),
            )
            square = laurent_mul(base, base)
            for p, r in itertools.combinations_with_replacement(range(4), 2):
                shift = [0] * 4
                shift[p] += 1
                shift[r] += 1
                shift[center] -= 2
                candidate = laurent_mul(square, {tuple(shift): Fraction(1)})
                ratio = sixth.proportional(reduced, candidate)
                if ratio is not None and ratio > 0:
                    return {"coefficient": str(ratio), "prefactor": f"s{p}*s{r}/s{center}^2",
                            "square": f"((s{center}-s{a})*(s{center}-s{b}))^2"}
    raise AssertionError("unrecognized C4 Laurent square")


def c4_certificate(poly, lower, edge_count):
    variables = 2 * edge_count
    z = list(range(edge_count))
    w = list(range(edge_count, 2 * edge_count))
    kind = lower["type"]
    if kind == "monomial_zero_branches":
        branches = []
        for branch in lower["branches"]:
            reduced = sixth.zero_edges(poly, edge_count, (branch["zero_edge"],))
            branches.append({"zero_edge": branch["zero_edge"],
                             "nonnegative_residual":
                                 sixth.nonnegative_s_polynomial(reduced, edge_count)})
        return {"type": "monomial_branches_nonnegative", "branches": branches}
    if kind == "square_equality_substitution":
        import re
        a, b, c, d = map(int, re.findall(r"z(\d)", lower["relation"]))
        sign = -1 if "=-1" in lower["relation"] else 1
        substitutions = {
            z[b]: sixth.replacement(variables, (w[c], w[d]), (z[a],), sign),
            w[b]: sixth.replacement(variables, (z[c], z[d]), (w[a],), sign),
        }
        reduced = sixth.substitute_monomials(poly, substitutions)
        square = c4_square_certificate(reduced)
        return {"type": "square_equality_reduction",
                "eighth_form": "zero" if square is None else square,
                "nonnegative": True}
    if kind == "long_am_gm_equality_substitution":
        substitutions = {
            w[2]: sixth.replacement(variables, (z[0], w[0]), (z[2],)),
            z[3]: sixth.replacement(variables, (w[0], w[1]), (z[2],), -1),
            w[3]: sixth.replacement(variables, (z[1], z[2]), (w[0],), -1),
        }
        assert not sixth.substitute_monomials(poly, substitutions)
        return {"type": kind, "eighth_form": "zero"}
    assert kind == "edge_collapse_components"
    for component in lower["components"]:
        assert not sixth.zero_edges(poly, edge_count, component["zero_edges"])
    return {"type": kind, "eighth_form": "zero"}


def gaussian_divide(a, b):
    norm = (b * b.conjugate()).real
    assert norm
    return (a * b.conjugate()).scale(Fraction(1, norm))


def verify_k4_representative(graph, seed):
    edges = dense.GRAPH_EDGES["K4"]
    edge_count = len(edges)
    variables = 2 * edge_count
    raw = descriptors(edges)
    symbolic = symbolic_features(edges, raw)
    z = list(range(edge_count))
    w = list(range(edge_count, 2 * edge_count))
    substitutions = {
        z[4]: sixth.replacement(variables, (z[2], z[3]), (z[1],)),
        w[4]: sixth.replacement(variables, (w[2], w[3]), (w[1],)),
    }
    reduced_symbolic = [sixth.substitute_monomials(poly, substitutions)
                        for poly in symbolic]
    monomials = sorted(set().union(*(poly.keys() for poly in reduced_symbolic)))
    matrix = [[poly.get(monomial, Fraction(0)) for poly in reduced_symbolic]
              for monomial in monomials]
    _, columns = sparse.rref(matrix)
    basis = [raw[i] for i in columns]
    basis_symbolic = [symbolic[i] for i in columns]

    samples = sixth.gaussian_samples(len(columns) + 20, seed)
    for sample in samples:
        sample[4] = gaussian_divide(sample[2] * sample[3], sample[1])
    rows = [feature_values(sample, edges, basis) for sample in samples]
    _, selected = sparse.rref([list(column) for column in zip(*rows)])
    assert len(selected) == len(columns)
    validation = [i for i in range(len(samples)) if i not in selected][:10]
    selected_rows, _, _, quotient_basis, _ = dense.exact_quotient(edges)
    # Ray 1 is the representative with equality z1*z4=z2*z3.
    ray = graph["rays"][1]
    functional = [
        sum(quotient_basis[j][r] * ray["ray"][j]
            for j in range(len(quotient_basis)))
        for r in range(14)
    ]
    indices = selected + validation
    evaluations = {}
    for i in indices:
        vector = eighth_minor_vector(samples[i], edges, selected_rows)
        evaluations[i] = sum(functional[r] * vector[r] for r in range(14))
    coefficients = fifth.solve_square(
        [rows[i] for i in selected], [evaluations[i] for i in selected]
    )
    assert all(sum(rows[i][j] * coefficients[j] for j in range(len(coefficients)))
               == evaluations[i] for i in validation)
    poly = sixth.combine_symbolic(coefficients, basis_symbolic)
    reduced = sixth.substitute_monomials(poly, substitutions)

    def monomial(numerator=(), denominator=()):
        return {sixth.replacement(variables, numerator, denominator)[1]: Fraction(1)}

    first = sixth.poly_add(
        monomial((w[0], z[1], z[1])),
        monomial((z[0], z[3], z[3])),
    )
    second = sixth.poly_add(
        monomial((w[5], z[2], z[2])),
        monomial((z[1], z[1], z[5])),
    )
    denominator = monomial((), (z[1], z[1], w[1], w[1]))
    expected = sixth.poly_scale(sixth.poly_product(
        [first, sixth.poly_conjugate(first, edge_count),
         second, sixth.poly_conjugate(second, edge_count), denominator],
        variables,
    ), Fraction(1, 144))
    assert reduced == expected
    return {
        "graph": "K4",
        "raw_invariant_basis_dimension": len(raw),
        "equality_restricted_invariant_rank": len(columns),
        "interpolation_samples": len(selected),
        "independent_validation_samples": len(validation),
        "representative_ray_index": 1,
        "representative_eighth_coefficients": [str(value) for value in coefficients],
        "sum_of_squares": (
            "|conj(z0)*z1^2+z0*z3^2|^2 * "
            "|conj(z5)*z2^2+z1^2*z5|^2 / (144*s1^2)"
        ),
        "S4_orbit_size": 3,
        "conclusion": "all three perfect-matching dual rays are nonnegative",
    }


def verify_eighth_order(sparse_path, dense_path, sixth_path, seventh_path):
    sparse_result = json.loads(Path(sparse_path).read_text())
    dense_result = json.loads(Path(dense_path).read_text())
    sixth_result = json.loads(Path(sixth_path).read_text())
    seventh_result = json.loads(Path(seventh_path).read_text())
    dense_by_name = {graph["graph"]: graph for graph in dense_result["graphs"]}
    sixth_by_name = {graph["graph"]: graph for graph in sixth_result["graphs"]}
    seventh_by_name = {graph["graph"]: graph
                       for graph in seventh_result["interpolated_graphs"]}
    graphs = [
        interpolate_full_graph("paw", dense_by_name["paw"],
                               seventh_by_name["paw"], 20268720),
        interpolate_full_graph("K4-e", dense_by_name["K4-e"],
                               seventh_by_name["K4-e"], 20269720),
        interpolate_full_graph("C4", sparse_result,
                               sixth_by_name["C4"], 20270720),
    ]
    k4 = verify_k4_representative(dense_by_name["K4"], 20271720)
    return {
        "statement": (
            "on every n=4 exact dual ray, joint lower-order equality makes "
            "the eighth dual form nonnegative"
        ),
        "consequence": (
            "the n=4 commuting boundary is non-outward through order eight; "
            "the first unresolved local coefficient is order nine"
        ),
        "basis_completeness": (
            "degree eight decomposes into directed cycle types 2+2+2+2, "
            "4+2+2, 3+3+2, and 4+4"
        ),
        "full_graphs": graphs,
        "K4_symmetry_representative": k4,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sparse-certificate", type=Path,
                        default=Path("results_quartic_cone_exact.json"))
    parser.add_argument("--dense-certificate", type=Path,
                        default=Path("results_quartic_dense_cone_exact.json"))
    parser.add_argument("--sixth-certificate", type=Path,
                        default=Path("results_sixth_order_exact.json"))
    parser.add_argument("--seventh-certificate", type=Path,
                        default=Path("results_seventh_order_exact.json"))
    parser.add_argument("--output", type=Path,
                        default=Path("results_eighth_order_exact.json"))
    args = parser.parse_args()
    result = verify_eighth_order(args.sparse_certificate, args.dense_certificate,
                                  args.sixth_certificate, args.seventh_certificate)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps({
        "output": str(args.output),
        "graphs": [{"graph": graph["graph"],
                    "raw_dimension": graph["raw_invariant_basis_dimension"],
                    "rank": graph["invariant_basis_rank"]}
                   for graph in result["full_graphs"]],
        "K4_equality_rank": result["K4_symmetry_representative"][
            "equality_restricted_invariant_rank"],
        "first_unresolved_order": 9,
    }, indent=2))


if __name__ == "__main__":
    main()
