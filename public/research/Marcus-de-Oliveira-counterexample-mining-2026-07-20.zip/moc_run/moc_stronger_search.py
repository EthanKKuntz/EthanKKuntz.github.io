#!/usr/bin/env python3
"""Test Kovacec's 2026 transposition-edge strengthening of MOC (n=4).

The 72 transposition chords are split at all crossings and converted to a
planar half-edge arrangement.  Bounded faces are recovered combinatorially;
determinants in the unbounded face violate the strengthening (but need not
violate the original convex-hull conjecture).
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

import numpy as np

import moc_search as m


def cross(z: complex, w: complex) -> float:
    return float(z.real * w.imag - z.imag * w.real)


def segment_intersection(p, r, q, s, tol=1e-11):
    den = cross(r, s)
    if abs(den) < tol:
        return None
    t = cross(q - p, s) / den
    u = cross(q - p, r) / den
    if -tol <= t <= 1 + tol and -tol <= u <= 1 + tol:
        return min(1.0, max(0.0, t)), min(1.0, max(0.0, u)), p + t * r
    return None


def transposition_pairs(perms):
    lookup = {tuple(p): i for i, p in enumerate(perms)}
    pairs = set()
    n = len(perms[0])
    for i, p in enumerate(perms):
        for a in range(n):
            for b in range(a + 1, n):
                q = p.copy()
                q[a], q[b] = q[b], q[a]
                j = lookup[tuple(q)]
                pairs.add(tuple(sorted((i, j))))
    return sorted(pairs)


def arrangement_faces(vertices, pairs):
    segments = [(vertices[i], vertices[j]) for i, j in pairs]
    cuts = [[(0.0, p), (1.0, q)] for p, q in segments]
    for i in range(len(segments)):
        p, q = segments[i]
        r = q - p
        for j in range(i + 1, len(segments)):
            a, b = segments[j]
            hit = segment_intersection(p, r, a, b - a)
            if hit is not None:
                ti, tj, z = hit
                cuts[i].append((ti, z))
                cuts[j].append((tj, z))

    radius = max(1.0, float(np.max(np.abs(vertices))))
    node_by_key = {}
    coords = []

    def node(z):
        key = (round(z.real / radius, 11), round(z.imag / radius, 11))
        if key not in node_by_key:
            node_by_key[key] = len(coords)
            coords.append(complex(key[0] * radius, key[1] * radius))
        return node_by_key[key]

    adjacency = {}
    for segcuts in cuts:
        ordered = sorted(segcuts, key=lambda x: x[0])
        dedup = []
        for t, z in ordered:
            if not dedup or abs(z - dedup[-1][1]) > 1e-9 * radius:
                dedup.append((t, z))
        for (_, z), (_, w) in zip(dedup, dedup[1:]):
            u, v = node(z), node(w)
            if u != v:
                adjacency.setdefault(u, set()).add(v)
                adjacency.setdefault(v, set()).add(u)

    orders = {}
    positions = {}
    for v, ns in adjacency.items():
        order = sorted(ns, key=lambda w: math.atan2((coords[w] - coords[v]).imag,
                                                    (coords[w] - coords[v]).real))
        orders[v] = order
        positions[v] = {w: i for i, w in enumerate(order)}

    seen = set()
    faces = []
    for u, ns in adjacency.items():
        for v in ns:
            if (u, v) in seen:
                continue
            start = (u, v)
            edge = start
            ids = []
            for _ in range(100000):
                if edge in seen:
                    break
                seen.add(edge)
                a, b = edge
                ids.append(a)
                order = orders[b]
                # Previous in CCW order from the reverse direction keeps the
                # traversed face on the left.
                k = positions[b][a]
                c = order[(k - 1) % len(order)]
                edge = (b, c)
                if edge == start:
                    break
            if edge == start and len(ids) >= 3:
                poly = np.asarray([coords[i] for i in ids])
                area = 0.5 * float(np.sum(poly.real * np.roll(poly.imag, -1)
                                          - poly.imag * np.roll(poly.real, -1)))
                if abs(area) > 1e-12 * radius * radius:
                    faces.append((area, poly))
    bounded = [poly for area, poly in faces if area > 0]
    outer = [poly for area, poly in faces if area < 0]
    return {"coordinates": coords, "bounded": bounded, "outer": outer,
            "face_areas": [area for area, _ in faces], "split_edge_count": sum(len(v) for v in adjacency.values()) // 2}


def on_segment(z, a, b, tol):
    return abs(cross(b - a, z - a)) <= tol * max(1.0, abs(b - a)) and \
        min(a.real, b.real) - tol <= z.real <= max(a.real, b.real) + tol and \
        min(a.imag, b.imag) - tol <= z.imag <= max(a.imag, b.imag) + tol


def point_in_polygon(z, poly):
    tol = 1e-10 * max(1.0, float(np.max(np.abs(poly))))
    inside = False
    for a, b in zip(poly, np.roll(poly, -1)):
        if on_segment(z, a, b, tol):
            return True
        if (a.imag > z.imag) != (b.imag > z.imag):
            xcross = (b.real - a.real) * (z.imag - a.imag) / (b.imag - a.imag) + a.real
            if z.real < xcross:
                inside = not inside
    return inside


def stronger_inside(z, arrangement):
    # For this connected arrangement the unique negative-area face walk is the
    # outer boundary.  Orientation does not affect the ray-crossing test.
    if len(arrangement["outer"]) == 1:
        return point_in_polygon(z, arrangement["outer"][0])
    return any(point_in_polygon(z, poly) for poly in arrangement["bounded"])


def survey_fixed(a, b, seed, samples):
    n = len(a)
    perms = m.permutations(n)
    vv = m.permutation_products(a, b, perms)
    pairs = transposition_pairs(perms)
    arr = arrangement_faces(vv, pairs)
    hull = m.monotone_hull(vv)
    rng = np.random.default_rng(seed)
    stronger_outside = 0
    moc_outside = 0
    first = None
    for k in range(samples):
        u = m.haar_unitary(n, rng)
        z = m.determinant_value(a, b, u)
        if not stronger_inside(z, arr):
            stronger_outside += 1
            if first is None:
                first = {"sample": k, "determinant": [z.real, z.imag],
                         "u": m.encode_complex_matrix(u),
                         "moc_geometry": m.geometry_validation(z, vv)}
        if float(np.max(m.polygon_facet_gaps(z, hull))) > 1e-10:
            moc_outside += 1
    return {"samples": samples, "transposition_edges": len(pairs),
            "arrangement_nodes": len(arr["coordinates"]),
            "split_edges": arr["split_edge_count"],
            "bounded_faces": len(arr["bounded"]), "outer_face_walks": len(arr["outer"]),
            "stronger_outside_count": stronger_outside, "moc_outside_count": moc_outside,
            "first_stronger_outside": first}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--samples", type=int, default=50000)
    ap.add_argument("--seed", type=int, default=20260720)
    ap.add_argument("--random-n5-instances", type=int, default=12)
    ap.add_argument("--random-n5-samples", type=int, default=3000)
    ap.add_argument("--output", type=Path, default=Path("results_stronger.json"))
    args = ap.parse_args()
    examples = [
        ("kovacec-figure-1",
         np.asarray([-0.344148+0.588535j, 0.549264+0.511072j,
                     0.783333+0.0101481j, 0.656687+0.599723j]),
         np.asarray([0.385389-0.341386j, -0.0787334+0.990329j,
                     0.129381+0.196029j, 0.498226+0.777095j])),
        ("kovacec-figure-2",
         np.asarray([-0.855349-0.134564j, -0.722786-0.625643j,
                     0.110147+0.0355084j, 0.717978+0.520418j]),
         np.asarray([-0.477374-0.905612j, -0.449772-0.0728638j,
                     0.548837-0.136747j, 0.176505+0.49083j])),
    ]
    out = {"source": "Kovacec DMUC 26-11 (2026)", "results": []}
    for j, (name, a, b) in enumerate(examples):
        out["results"].append({"name": name, "a": m.encode_complex_vector(a),
                               "b": m.encode_complex_vector(b),
                               "survey": survey_fixed(a, b, args.seed + j, args.samples)})
    rng = np.random.default_rng(args.seed + 500)
    out["random_n5"] = []
    for j in range(args.random_n5_instances):
        a, b = m.normalize_spectra(rng.normal(size=5) + 1j * rng.normal(size=5),
                                   rng.normal(size=5) + 1j * rng.normal(size=5))
        survey = survey_fixed(a, b, args.seed + 1000 + j, args.random_n5_samples)
        out["random_n5"].append({"instance": j, "a": m.encode_complex_vector(a),
                                 "b": m.encode_complex_vector(b), "survey": survey})
    args.output.write_text(json.dumps(out, indent=2))
    print(json.dumps({"output": str(args.output), "samples_each": args.samples,
                      "random_n5_instances": args.random_n5_instances,
                      "random_n5_samples": args.random_n5_samples}, indent=2))


if __name__ == "__main__":
    main()
