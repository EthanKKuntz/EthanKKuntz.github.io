#!/usr/bin/env python3
"""Independent high-precision verifier for JSON candidates from moc_search.py.

This file deliberately does not import the search module.  It uses Decimal
complex arithmetic, Leibniz determinants, exhaustive permutation products,
and direct support inequalities.
"""

from __future__ import annotations

import argparse
import itertools
import json
from decimal import Decimal, getcontext
from pathlib import Path


def cadd(z, w):
    return (z[0] + w[0], z[1] + w[1])


def csub(z, w):
    return (z[0] - w[0], z[1] - w[1])


def cmul(z, w):
    return (z[0] * w[0] - z[1] * w[1], z[0] * w[1] + z[1] * w[0])


def cconj(z):
    return (z[0], -z[1])


def cabs2(z):
    return z[0] * z[0] + z[1] * z[1]


def dcomplex(pair):
    # str(float) preserves the exact decimal text certified by the JSON input.
    return (Decimal(str(pair[0])), Decimal(str(pair[1])))


def parity(p):
    inv = sum(p[i] > p[j] for i in range(len(p)) for j in range(i + 1, len(p)))
    return -1 if inv % 2 else 1


def det_leibniz(m):
    n = len(m)
    total = (Decimal(0), Decimal(0))
    for p in itertools.permutations(range(n)):
        term = (Decimal(parity(p)), Decimal(0))
        for i in range(n):
            term = cmul(term, m[i][p[i]])
        total = cadd(total, term)
    return total


def determinant_value(a, b, u):
    n = len(a)
    m = [[(Decimal(0), Decimal(0)) for _ in range(n)] for _ in range(n)]
    for i in range(n):
        m[i][i] = a[i]
    for i in range(n):
        for j in range(n):
            s = (Decimal(0), Decimal(0))
            for k in range(n):
                s = cadd(s, cmul(cmul(u[i][k], b[k]), cconj(u[j][k])))
            m[i][j] = cadd(m[i][j], s)
    return det_leibniz(m)


def vertices(a, b):
    out = []
    for p in itertools.permutations(range(len(a))):
        z = (Decimal(1), Decimal(0))
        for i in range(len(a)):
            z = cmul(z, cadd(a[i], b[p[i]]))
        out.append((p, z))
    return out


def dot(direction, z):
    # Re(conj(direction) z)
    return direction[0] * z[0] + direction[1] * z[1]


def closest_edge_indices(z, vv):
    """Independent float hull pass used only to select an edge to certify."""
    pts = [(float(v[0]), float(v[1]), i) for i, (_, v) in enumerate(vv)]
    pts.sort()
    unique = []
    for p in pts:
        if not unique or abs(p[0] - unique[-1][0]) + abs(p[1] - unique[-1][1]) > 1e-13:
            unique.append(p)

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in unique:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(unique):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    hull = lower[:-1] + upper[:-1]
    zf = (float(z[0]), float(z[1]))
    best = None
    for a, b in zip(hull, hull[1:] + hull[:1]):
        ex, ey = b[0] - a[0], b[1] - a[1]
        direction = (ey, -ex)  # outward (right) normal of a CCW edge
        gap = direction[0] * zf[0] + direction[1] * zf[1]
        support = max(direction[0] * p[0] + direction[1] * p[1] for p in unique)
        item = (gap - support, a[2], b[2])
        if best is None or item[0] > best[0]:
            best = item
    return best


def verify_candidate(c, precision):
    getcontext().prec = precision
    a = [dcomplex(z) for z in c["a"]]
    b = [dcomplex(z) for z in c["b"]]
    u = [[dcomplex(z) for z in row] for row in c["u"]]
    z = determinant_value(a, b, u)
    vv = vertices(a, b)
    # The stored theta is converted once in binary floating point.  This check
    # is high precision in all algebraic data; for an exact proof one instead
    # stores a rational/algebraic edge normal and reruns the same dot products.
    import math
    direction = (Decimal(str(math.cos(c["theta"]))),
                 Decimal(str(math.sin(c["theta"]))))
    scored = [(p, dot(direction, v)) for p, v in vv]
    active, support = max(scored, key=lambda x: x[1])
    gap = dot(direction, z) - support
    edge_choice = closest_edge_indices(z, vv)
    edge_report = None
    if edge_choice is not None:
        _, ia, ib = edge_choice
        pa, va = vv[ia]
        pb, vb = vv[ib]
        edge = csub(vb, va)
        edge_direction = (edge[1], -edge[0])
        edge_scored = [(p, dot(edge_direction, v)) for p, v in vv]
        edge_active, edge_support = max(edge_scored, key=lambda x: x[1])
        edge_gap = dot(edge_direction, z) - edge_support
        edge_report = {
            "endpoint_permutations": [list(pa), list(pb)],
            "direction": [str(edge_direction[0]), str(edge_direction[1])],
            "active_permutation": list(edge_active),
            "support_gap_unnormalized_normal": str(edge_gap),
            "all_vertex_scores_le_support": all(s <= edge_support for _, s in edge_scored),
        }
    # High-precision normality/unitarity residual for the supplied decimal data.
    one = Decimal(1)
    max_uerr2 = Decimal(0)
    n = len(u)
    for i in range(n):
        for j in range(n):
            s = (Decimal(0), Decimal(0))
            for k in range(n):
                s = cadd(s, cmul(cconj(u[k][i]), u[k][j]))
            if i == j:
                s = csub(s, (one, Decimal(0)))
            max_uerr2 = max(max_uerr2, cabs2(s))
    return {
        "precision_digits": precision,
        "dimension": n,
        "determinant": [str(z[0]), str(z[1])],
        "support_gap": str(gap),
        "active_permutation": list(active),
        "active_support": str(support),
        "max_unitarity_residual_squared": str(max_uerr2),
        "vertex_count": len(vv),
        "all_vertex_scores_le_support": all(s <= support for _, s in scored),
        "closest_edge_check": edge_report,
    }


def collect_candidates(data):
    out = []
    for r in data.get("results", []):
        c = r.get("best")
        if c is not None:
            out.append(c)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--index", type=int, default=None,
                    help="candidate index; default verifies the largest stored normalized gap")
    ap.add_argument("--precision", type=int, default=100)
    ap.add_argument("--output", type=Path, default=None)
    args = ap.parse_args()
    data = json.loads(args.input.read_text())
    candidates = collect_candidates(data)
    if not candidates:
        raise SystemExit("no candidates")
    idx = args.index
    if idx is None:
        idx = max(range(len(candidates)), key=lambda j: candidates[j]["normalized_gap"])
    report = {"source": str(args.input), "candidate_index": idx,
              "family": candidates[idx]["family"],
              "stored_normalized_gap": candidates[idx]["normalized_gap"],
              "verification": verify_candidate(candidates[idx], args.precision)}
    text = json.dumps(report, indent=2)
    if args.output:
        args.output.write_text(text)
    print(text)


if __name__ == "__main__":
    main()
