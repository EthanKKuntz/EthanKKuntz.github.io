# Marcus–de Oliveira counterexample-mining report

**Result (20 July 2026): no credible counterexample was found in dimensions 4, 5, or 6, and the
`n=4` commuting boundary is now certified non-outward through order eight.**  If its quadratic
outward coefficient vanishes, the cubic coefficient vanishes and the quartic coefficient is
nonpositive; if the quartic coefficient also vanishes, the fifth coefficient vanishes and the
sixth coefficient is nonpositive; if that also vanishes, the seventh coefficient vanishes and the
eighth coefficient is nonpositive.  Thus the first unresolved local mechanism is ninth order.

This is negative computational evidence, not a proof of the conjecture.

**Exact boundary update.**  Four exact coefficient-cone calculations exhaust the `n=4` active
support graphs.  The `4`-cycle, paw, `K_4-e`, and `K_4` certificates enumerate `38` dual rays in
total and reduce every quartic form to a nonnegative monomial or two-term AM–GM inequality.
Exact Gaussian-rational interpolation then proves that quartic equality forces fifth-order
equality and nonnegative sixth/eighth dual forms, with seventh-order equality between them.  See
`QUARTIC_ATTACK_REPORT.md`,
`moc_quartic_cone.py`, `moc_quartic_dense_cone.py`, `moc_fifth_order.py`,
`moc_sixth_order.py`, `moc_seventh_order.py`, `moc_eighth_order.py`, and their exact JSON
certificates.

## 1. Boundary reduction obtained in this run

After relabelling the spectrum of `B`, let

\[
 A=\operatorname{diag}(a_i),\quad B=\operatorname{diag}(b_i),\quad
 z_\sigma=\prod_i(a_i+b_{\sigma(i)}),
\]

and let `K` be skew-Hermitian.  For

\[
 f(t)=\det(A+e^{tK}Be^{-tK}),
\]

direct differentiation at the commuting point gives

\[
 f'(0)=0,\qquad
 f''(0)=2\sum_{i<j}|K_{ij}|^2\bigl(z_{(ij)}-z_{\mathrm{id}}\bigr). \tag{1}
\]

Thus the second variation is a nonnegative combination of chords from the identity
permutation vertex to transposition vertices.  If a real-linear functional `L` supports the
permutation polygon at `z_id`, then

\[
 (L\circ f)''(0)
 =2\sum_{i<j}|K_{ij}|^2\bigl(L(z_{(ij)})-L(z_{\mathrm{id}})\bigr)\le0.
\]

Consequently no outward violation can appear at order `t²` near a permutation unitary.  To
justify the stronger, quartic conclusion, one more step is needed.  Put

\[
 q_{ij}=L(z_{(ij)})-L(z_{\mathrm{id}})\le 0,
 \qquad g(t)=L(f(t))-L(z_{\mathrm{id}}).
\]

If `g''(0)<0`, the curve is locally inward.  If `g''(0)=0`, equation (1) and `q_ij <= 0`
imply that `K_ij=0` whenever `q_ij<0`.  Now every monomial in `g'''(0)` is supported on at
most three coordinate indices.  Group these monomials by their supports `T`, with `|T| <= 3`,
and restrict `K` to each such coordinate block.  That restricted unitary fixes all other
coordinates, so the known Marcus–de Oliveira theorem in dimensions at most three puts the
resulting determinant curve in the convex hull of the permutations supported on `T`.  Since
`L` supports all of those vertices at `z_id`, the restricted real curve is nonpositive for both
signs of `t`.  Its linear term vanishes, and its quadratic term vanishes by the preceding
`q_ij` condition; hence its cubic coefficient must vanish.  Summing over `T` gives

\[
 g''(0)=0\quad\Longrightarrow\quad g'''(0)=0.
\]

Thus the first algebraically possible term was fourth order.  The exact certificates described
above rule out a positive fourth-order coefficient for every `n=4` active graph and show that
equality also kills the fifth- and seventh-order coefficients and leaves the sixth and eighth
coefficients nonpositive.  A local outward bifurcation along an off-diagonal one-parameter
direction must therefore first occur at order nine (or in a singular
limiting problem where the chosen normalization or supporting face degenerates).

Equation (1) is consistent with, and extends infinitesimally to arbitrary skew-Hermitian
directions, Kovačec's April 2026 proposition that a single Givens rotation traces exactly the
segment between two transposition-related permutation products.  The numerical implementation
checked (1) by centered finite differences in 360 random cases; median relative errors were
`1.4e-8`, `2.1e-8`, and `2.3e-8` for `n=4,5,6`.

## 2. Verified status and reductions

The conjecture remains open for `n >= 4`.  The current DeepMind formalization is a faithful
diagonal-unitary statement and remains marked `research open` with a `sorry`.  It uses two
unitaries because mathlib does not presently expose eigenvalue vectors for arbitrary normal
non-Hermitian matrices; passing to the relative unitary gives the normalization used here.

The search excluded or used as controls the main known positive regions:

- `n <= 3`;
- Hermitian pairs and the more general line/circle or essentially-Hermitian spectral cases;
- scalar multiples of unitaries;
- one spectrum with at least `n-2` equal eigenvalues;
- `n=4` with a Householder reflection;
- direct sums of known MOC pairs and normal-dilation constructions;
- the 2025 Shitov case in which all eigenvalues are real except possibly three eigenvalues of
  one matrix;
- the 2026 variational result that if `A+B` is singular, then zero lies in the permutation hull.

Primary/recent sources:

- [FormalConjectures Lean statement](https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/Wikipedia/DeterminantalConjecture.lean)
- [Bebiano–da Providência, *Revisiting the Marcus–de Oliveira Conjecture* (2025)](https://doi.org/10.3390/math13050711)
- [Shitov, *A further sufficient condition for the determinantal conjecture* (2025)](https://www.mathnet.ru/eng/im9292)
- [Mulero-Martínez, *A variational framework…* (2026)](https://doi.org/10.1016/j.laa.2026.03.019)
- [Kovačec, *A conjecture more precise and stronger…* (2026)](https://www.mat.uc.pt/preprints/ps/p2611.pdf)
- [Drury, counterexample to the stronger minor/compound conjecture (1992)](https://doi.org/10.1016/0024-3795(92)90296-M)

## 3. Objective and parameterizations

The principal objective was the normalized support gap

\[
 \delta(a,b,U,\theta)=
 \frac{\Re(e^{-i\theta}\det(A+UBU^*))-
 \max_\sigma\Re(e^{-i\theta}z_\sigma)}
 {\max\{|\det(A+UBU^*)|,(|S_n|^{-1}\sum_\sigma|z_\sigma|^2)^{1/2}\}}.
\]

Any strictly positive value is already a separating real-linear functional and hence a
counterexample.  Optimization used a log-sum-exp smoothing, followed by exact evaluation of
the finite maximum.  Spectra were shift-gauged (`mean(a)=0`) and RMS-scaled, operations which
preserve convex-hull membership.

Unitary families:

- Haar QR samples;
- full Hermitian exponential coordinates `U=exp(iH)`;
- full Cayley coordinates `(I-iH/2)^{-1}(I+iH/2)`;
- exactly unitary Gaussian-rational Cayley matrices from Gaussian-integer Hermitian `H`;
- Fourier/Hadamard matrices;
- uniform Householder reflections;
- Drury's algebraic `n=4` unitary counterexample to the stronger Merikoski–Virtanen conjecture;
- near-block unitaries and logarithmically spaced perturbations of permutation unitaries.

Spectral families included generic complex Gaussians, Gaussian integers, repeated spectra,
zero plus roots of unity, and continuous spectra optimized jointly with the unitary and support
direction.  Robust joint runs constrained the unitary away from monomial matrices and kept
spectral pair distances above a small threshold; unconstrained runs were retained specifically
to study boundary attraction.

## 4. Main numerical results

“Direct samples” below excludes optimizer evaluations.  `Outside = 0` uses a normalized
tolerance of `1e-10`; apparent `1e-14` excursions in repeated/root spectra were degenerate-hull
roundoff and were classified as zero by LP and high-precision checks.

| n | Direct samples | Fixed-unitary global optimizations | Robust joint restarts | Near-permutation samples | Outside |
|---:|---:|---:|---:|---:|---:|
| 4 | 56,000 | 8 | 16 | 12,000 | 0 |
| 5 | 34,000 | 6 | 14 | 12,000 | 0 |
| 6 | 15,500 | 4 | 10 | 12,000 | 0 |

The fixed-unitary differential-evolution stages used at least 169,588 objective evaluations in
total, followed by Nelder–Mead polishing.  The table does not count Powell evaluations in the
40 robust joint restarts.

### Structured attacks

| Family | n | Best normalized support gap |
|---|---:|---:|
| Drury MVC counterexample unitary | 4 | `-1.0031e-3` |
| Uniform Householder (MVC-valid control) | 4 | `-8.2820e-4` |
| Uniform Householder (MVC counterexample family) | 5 | `-2.5229e-3` |
| Fourier | 4 | `-6.9327e-4` |
| Fourier | 5 | `-1.9184e-4` |
| Fourier | 6 | `-5.7520e-4` |
| Gaussian-integer spectra + rational Cayley `U` | 4 | `-4.7177e-4` |
| same | 5 | `-8.9896e-3` |
| same | 6 | `-7.5043e-2` |

The failure of the stronger minor-convexity conjecture did not transfer.  At any fixed degree,
a support functional produced by spectra has coefficient matrix
`Re(c x_I y_J)`, of real rank at most two, while Drury's displayed separating facet has rank
three in degree two.  Terms of other degrees are also coupled by the same spectra.  This is a
structural obstruction to a naive projection of Drury's witness into MOC.

### Boundary-focused experiment

For each dimension, 12,000 trials began at an exposed permutation vertex and used
`U=exp(tK)` with `t` spread over `[1e-3,1]`.  There were no violations in any of four logarithmic
bins.  The best support gaps became more negative, rather than turning outward, as `t` grew:

| n | best, `t in [1e-3,1e-2]` | best, `t in [0.2,1]` |
|---:|---:|---:|
| 4 | `-4.71e-8` | `-9.09e-4` |
| 5 | `-5.66e-8` | `-3.69e-3` |
| 6 | `-9.26e-8` | `-4.50e-3` |

This is exactly the qualitative behavior predicted by (1).

## 5. Independent and high-precision validation

Every retained candidate was checked by three independent convex-membership implementations:

1. a local monotone-chain hull and signed edge inequalities;
2. SciPy/Qhull half-space equations;
3. an LP for nonnegative convex weights with total weight one.

The high-precision verifier is independent of the search module.  It uses 120-digit Decimal
complex arithmetic, Leibniz determinants, all `n!` permutation products, and an exact
(relative to the stored decimal data) outward normal obtained from the closest hull edge.

The closest generic robust candidates remained inside:

| n | high-precision closest-edge support gap | max squared unitarity residual |
|---:|---:|---:|
| 4 | `-2.9325830189e-13` | `1.22e-30` |
| 5 | `-5.2075426206e-13` | `2.27e-31` |
| 6 | `-7.8439324943e-14` | `2.66e-31` |

One unconstrained Cayley run initially appeared positive by `2.72e-11`, but its Cayley solve
had become ill-conditioned: the squared unitarity residual was `2.98e-10` (unitarity error far
larger than the claimed gap).  It was rejected, and bounding the Cayley chart removed the
artifact.  This is a concrete example of why hull geometry alone is insufficient.

## 6. Test of Kovačec's stronger 2026 polygon

I implemented the nonconvex transposition-edge construction from DMUC 26-11 by splitting all
segment intersections, constructing the planar half-edge arrangement, and identifying its
unique outer face.

- Kovačec's two published `n=4` spectral examples: 20,000 Haar unitaries each, no point outside
  the stronger polygon and no MOC violation.
- `n=5`: 12 independent generic spectral pairs, 3,000 Haar unitaries per pair (36,000 total),
  no point outside the stronger polygon and no MOC violation.  The arrangements contained
  roughly 12,700–18,000 nodes and 13,100–18,400 bounded faces.

This supplies the `n>=5` experiment explicitly requested in the conclusion of that preprint.
It is evidence only; the planar arrangement uses double precision.

## 7. Reproduction

Core commands used:

```bash
python -m unittest -v

python moc_search.py --dimensions 4 --random-samples 20000 --block-samples 6000 \
  --root-samples 10000 --rational-samples 10000 --de-iters 90 --popsize 7 \
  --polish-iters 1600 --haar-optimized 5 --joint-modes cayley exp \
  --joint-iters 700 --joint-starts 6 --output results_n4.json

python moc_search.py --dimensions 5 --random-samples 12000 --block-samples 4000 \
  --root-samples 6000 --rational-samples 6000 --de-iters 75 --popsize 6 \
  --polish-iters 1400 --haar-optimized 4 --joint-modes cayley exp \
  --joint-iters 800 --joint-starts 7 --output results_n5.json

python moc_search.py --dimensions 6 --random-samples 6000 --block-samples 2000 \
  --root-samples 2500 --rational-samples 2500 --de-iters 50 --popsize 5 \
  --polish-iters 1000 --haar-optimized 2 --joint-modes cayley exp \
  --joint-iters 600 --joint-starts 5 --output results_n6.json

python moc_boundary_search.py --dimensions 4 5 6 --samples 12000 \
  --output results_boundary.json

python moc_stronger_search.py --samples 20000 --output results_stronger.json
python moc_stronger_search.py --samples 5000 --random-n5-instances 12 \
  --random-n5-samples 3000 --output results_stronger_n5.json

python moc_verify.py results_n5.json --index 12 --precision 120 \
  --output verify_n5_closest.json

python moc_quartic_cone.py --output results_quartic_cone_exact.json
python moc_quartic_dense_cone.py --output results_quartic_dense_cone_exact.json
python moc_fifth_order.py --output results_fifth_order_exact.json
python moc_sixth_screen.py --samples 300 --output results_sixth_screen.json
python moc_sixth_order.py --output results_sixth_order_exact.json
python moc_seventh_order.py --output results_seventh_order_exact.json
python moc_eighth_order.py --output results_eighth_order_exact.json
```

All searches use explicit seeds stored in the JSON results.

## 8. Best next experiment

Do not simply add Haar samples.  The exact graph census and invariant calculations have removed
orders four through eight from the local `n=4` attack.  The degree-eight calculation uses complete
invariant ranks `39`, `101`, and `46` for the paw, `K_4-e`, and `C_4`, plus a rank-`175`
equality-restricted basis for the `K_4` symmetry representative.  The best next local experiment
is an exact ninth-order calculation on the eighth-order equality strata.  Fully dense `K_4` rays
already annihilate every odd order and `C_4` is bipartite, leaving the paw and `K_4-e` strata as
the only genuinely new cases.

In parallel, the Kovačec polygon remains the sharper global target for departures far from
permutation unitaries, especially at `n=5` where the arrangement implementation is already
available.

## 9. Lean

No exact outside candidate exists to certify, so a Lean counterexample certificate was not
attempted.  If one appears, the shortest formal route is to choose rational/Gaussian-rational
spectra and a rational Cayley unitary, provide a rational real-linear separator, expand the
finite `S_n` maximum by `native_decide`/finite enumeration, and prove:

- the Cayley denominator is invertible and `U*U=I`;
- both matrices are normal and have the stated diagonal spectra;
- the determinant equals the claimed Gaussian rational;
- every permutation product satisfies the separator inequality;
- the determinant violates it strictly.

The current FormalConjectures file already supplies the correct ambient statement; the main
library work would be automation for finite complex matrix determinants and Gaussian-rational
inequalities.
