#!/usr/bin/env python3
"""Exact sixth-order certificate at every n=4 commuting boundary point.

The exact quartic cone calculation reduces the local Marcus--de Oliveira
problem to finitely many dual rays.  The fifth-order calculation proves that
the odd coefficient following a quartic equality is zero.  This script proves
the next assertion, entirely over the rationals:

    on the zero set of every quartic dual form, the sixth dual form is
    nonnegative.

Here ``dual form nonnegative'' means that the determinant motion is inward in
the sign convention of the quartic cone certificates.  The invariant bases
are complete: a degree-six diagonal-gauge invariant is a union of cycles of
types 2+2+2, 4+2, or 3+3.  We interpolate in those bases from Gaussian-rational
Taylor series and verify every equality substitution as a Laurent-polynomial
identity.  No floating-point arithmetic is used.

This is a local one-parameter theorem, not a proof of the global conjecture.
"""

from __future__ import annotations

import argparse
import itertools
import json
import random
from fractions import Fraction
from pathlib import Path

import moc_fifth_order as fifth
import moc_quartic_cone as sparse
import moc_quartic_dense_cone as dense


EDGES = tuple(itertools.combinations(range(4), 2))
TRIANGLES = ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3))
CYCLES = dense.HAMILTONIAN_CYCLES


def sixth_minor_vector(values, edges, selected_rows):
    order = 6
    u = fifth.unitary_series(fifth.generator(values, edges), order)
    answer = []
    for row in selected_rows:
        i_set, j_set = sparse.ROWS[row]
        determinant = fifth.minor_series(u, i_set, j_set, order)
        absolute_square = fifth.convolution(
            determinant, [entry.conjugate() for entry in determinant], order
        )
        assert absolute_square[order].imag == 0
        answer.append(absolute_square[order].real)
    return answer


def cycle_value(k, cycle):
    out = fifth.ONE
    for i, j in zip(cycle, cycle[1:] + cycle[:1]):
        out = out * k[i][j]
    return out


def feature_descriptors(name, edge_count):
    descriptors = [("sss", combo)
                   for combo in itertools.combinations_with_replacement(
                       range(edge_count), 3)]
    if name == "paw":
        descriptors.append(("tt", TRIANGLES[0], TRIANGLES[0], False))
    elif name == "K4-e":
        cycle = (0, 2, 1, 3)
        descriptors += [("sp", edge, cycle) for edge in range(edge_count)]
        triangles = TRIANGLES[:2]
        descriptors += [
            ("tt", triangles[0], triangles[0], False),
            ("tt", triangles[1], triangles[1], False),
            ("tt", triangles[0], triangles[1], False),
        ]
    elif name == "C4":
        descriptors += [("sp", edge, (0, 1, 2, 3))
                        for edge in range(edge_count)]
    elif name == "K4":
        descriptors += [("sp", edge, cycle)
                        for cycle in CYCLES for edge in range(edge_count)]
        descriptors += [("tt", triangle, triangle, False)
                        for triangle in TRIANGLES]
        descriptors += [("tt", a, b, False)
                        for a, b in itertools.combinations(TRIANGLES, 2)]
        descriptors += [("tt", a, b, True)
                        for a, b in itertools.combinations(TRIANGLES, 2)]
    else:
        raise ValueError(name)
    return descriptors


def descriptor_name(descriptor):
    kind = descriptor[0]
    if kind == "sss":
        return "".join(f"s{i}" for i in descriptor[1])
    if kind == "sp":
        return f"s{descriptor[1]}P{''.join(map(str, descriptor[2]))}"
    _, a, b, conjugate_second = descriptor
    left = "T" + "".join(map(str, a))
    right = ("conj(T" if conjugate_second else "T") + "".join(map(str, b))
    if conjugate_second:
        right += ")"
    return f"Re({left}*{right})"


def feature_values(values, edges, descriptors):
    k = fifth.generator(values, edges)
    squared = fifth.squared_magnitudes(values)
    answer = []
    for descriptor in descriptors:
        kind = descriptor[0]
        if kind == "sss":
            value = Fraction(1)
            for edge in descriptor[1]:
                value *= squared[edge]
            answer.append(value)
        elif kind == "sp":
            answer.append(squared[descriptor[1]] *
                          cycle_value(k, descriptor[2]).real)
        else:
            _, a, b, conjugate_second = descriptor
            first_value = cycle_value(k, a)
            second_value = cycle_value(k, b)
            if conjugate_second:
                second_value = second_value.conjugate()
            answer.append((first_value * second_value).real)
    return answer


def gaussian_samples(count, seed):
    rng = random.Random(seed)
    samples = []
    for _ in range(count):
        sample = []
        for _ in range(6):
            while True:
                pair = (rng.randint(-2, 2), rng.randint(-2, 2))
                if pair != (0, 0):
                    break
            sample.append(fifth.Gaussian(Fraction(pair[0]), Fraction(pair[1])))
        samples.append(sample)
    return samples


def independent_feature_system(name, edges, seed):
    raw = feature_descriptors(name, len(edges))
    candidates = gaussian_samples(max(110, 2 * len(raw) + 10), seed)
    raw_rows = [feature_values(sample[:len(edges)], edges, raw)
                for sample in candidates]
    _, pivot_columns = sparse.rref(raw_rows)
    descriptors = [raw[i] for i in pivot_columns]
    rows = [[row[i] for i in pivot_columns] for row in raw_rows]
    _, pivot_rows = sparse.rref([list(column) for column in zip(*rows)])
    rank = len(pivot_columns)
    assert len(pivot_rows) == rank
    interpolation = pivot_rows
    validation = [i for i in range(len(candidates)) if i not in pivot_rows][:10]
    return raw, descriptors, candidates, rows, interpolation, validation


# Laurent polynomials in z_0,...,z_(m-1),w_0,...,w_(m-1).
# Negative exponents occur only after equality substitutions.
def poly_clean(poly):
    return {monomial: coefficient for monomial, coefficient in poly.items()
            if coefficient}


def poly_add(*polys):
    out = {}
    for poly in polys:
        for monomial, coefficient in poly.items():
            out[monomial] = out.get(monomial, Fraction(0)) + coefficient
    return poly_clean(out)


def poly_scale(poly, coefficient):
    return poly_clean({monomial: coefficient * value
                       for monomial, value in poly.items()})


def poly_mul(a, b):
    out = {}
    for ma, ca in a.items():
        for mb, cb in b.items():
            monomial = tuple(x + y for x, y in zip(ma, mb))
            out[monomial] = out.get(monomial, Fraction(0)) + ca * cb
    return poly_clean(out)


def poly_product(polys, variables):
    out = {(0,) * variables: Fraction(1)}
    for poly in polys:
        out = poly_mul(out, poly)
    return out


def poly_variable(index, variables, coefficient=Fraction(1)):
    exponent = [0] * variables
    exponent[index] = 1
    return {tuple(exponent): coefficient}


def poly_conjugate(poly, edge_count):
    out = {}
    for monomial, coefficient in poly.items():
        swapped = monomial[edge_count:] + monomial[:edge_count]
        out[swapped] = out.get(swapped, Fraction(0)) + coefficient
    return poly_clean(out)


def symbolic_generator(edges):
    variables = 2 * len(edges)
    zero = {}
    k = [[zero for _ in range(4)] for _ in range(4)]
    for edge, (i, j) in enumerate(edges):
        k[i][j] = poly_variable(edge, variables)
        k[j][i] = poly_variable(len(edges) + edge, variables, Fraction(-1))
    return k


def symbolic_cycle(k, cycle, variables):
    return poly_product(
        [k[i][j] for i, j in zip(cycle, cycle[1:] + cycle[:1])],
        variables,
    )


def symbolic_features(edges, descriptors):
    edge_count = len(edges)
    variables = 2 * edge_count
    k = symbolic_generator(edges)
    s = [poly_mul(poly_variable(i, variables),
                  poly_variable(edge_count + i, variables))
         for i in range(edge_count)]
    answer = []
    for descriptor in descriptors:
        kind = descriptor[0]
        if kind == "sss":
            answer.append(poly_product([s[i] for i in descriptor[1]], variables))
        elif kind == "sp":
            p = symbolic_cycle(k, descriptor[2], variables)
            real_p = poly_scale(poly_add(p, poly_conjugate(p, edge_count)),
                                Fraction(1, 2))
            answer.append(poly_mul(s[descriptor[1]], real_p))
        else:
            _, a, b, conjugate_second = descriptor
            first_value = symbolic_cycle(k, a, variables)
            second_value = symbolic_cycle(k, b, variables)
            if conjugate_second:
                second_value = poly_conjugate(second_value, edge_count)
            product = poly_mul(first_value, second_value)
            answer.append(poly_scale(
                poly_add(product, poly_conjugate(product, edge_count)),
                Fraction(1, 2),
            ))
    return answer


def combine_symbolic(coefficients, features):
    return poly_add(*(poly_scale(feature, coefficient)
                      for coefficient, feature in zip(coefficients, features)))


def substitute_monomials(poly, replacements):
    """Simultaneously replace variables by signed Laurent monomials."""
    out = {}
    for original, coefficient in poly.items():
        exponent = list(original)
        value = coefficient
        for variable, (sign, replacement) in replacements.items():
            power = exponent[variable]
            if not power:
                continue
            exponent[variable] = 0
            value *= sign ** power
            for i, replacement_power in enumerate(replacement):
                exponent[i] += power * replacement_power
        monomial = tuple(exponent)
        out[monomial] = out.get(monomial, Fraction(0)) + value
    return poly_clean(out)


def replacement(variables, numerator=(), denominator=(), sign=1):
    exponent = [0] * variables
    for index in numerator:
        exponent[index] += 1
    for index in denominator:
        exponent[index] -= 1
    return Fraction(sign), tuple(exponent)


def zero_edges(poly, edge_count, edges):
    forbidden = set(edges) | {edge_count + edge for edge in edges}
    return poly_clean({monomial: coefficient
                       for monomial, coefficient in poly.items()
                       if all(monomial[index] == 0 for index in forbidden)})


def proportional(a, b):
    if not a:
        return Fraction(0) if b else Fraction(1)
    if not b or set(a) != set(b):
        return None
    first = next(iter(a))
    ratio = a[first] / b[first]
    return ratio if all(a[key] == ratio * b[key] for key in a) else None


def nonnegative_s_polynomial(poly, edge_count):
    terms = []
    for monomial, coefficient in sorted(poly.items()):
        assert coefficient >= 0
        assert monomial[:edge_count] == monomial[edge_count:]
        terms.append({
            "coefficient": str(coefficient),
            "s_exponents": list(monomial[:edge_count]),
        })
    return terms


def paw_certificate(poly, pattern, names, edge_count):
    nonzero = [i for i, value in enumerate(pattern) if value]
    if not nonzero:
        assert not poly
        return {"type": "sixth_form_identically_zero"}
    assert len(nonzero) == 1 and names[nonzero[0]].startswith("s")
    name = names[nonzero[0]]
    left, right = int(name[1]), int(name[3])
    branches = []
    for edge in (left, right):
        reduced = zero_edges(poly, edge_count, (edge,))
        branches.append({
            "zero_edge": edge,
            "nonnegative_residual": nonnegative_s_polynomial(reduced, edge_count),
        })
    return {"type": "monomial_zero_branches", "quartic_monomial": name,
            "branches": branches}


def k4e_certificate(poly, pattern, names, edge_count):
    nonzero = [i for i, value in enumerate(pattern) if value]
    cycle_column = names.index("P0213")
    if cycle_column not in nonzero:
        assert len(nonzero) == 1
        name = names[nonzero[0]]
        left, right = int(name[1]), int(name[3])
        branches = []
        for edge in (left, right):
            reduced = zero_edges(poly, edge_count, (edge,))
            assert not reduced
            branches.append({"zero_edge": edge, "sixth_form": "zero"})
        return {"type": "monomial_zero_branches",
                "quartic_monomial": name, "branches": branches}

    pair_names = [names[i] for i in nonzero if i != cycle_column]
    cycle_coefficient = pattern[cycle_column]
    variables = 2 * edge_count
    z = list(range(edge_count))
    w = list(range(edge_count, 2 * edge_count))
    if set(pair_names) == {"s1s4", "s2s3"}:
        substitutions = {
            z[4]: replacement(variables, (z[2], z[3]), (z[1],)),
            w[4]: replacement(variables, (w[2], w[3]), (w[1],)),
        }
        reduced = substitute_monomials(poly, substitutions)
        assert not reduced
        return {"type": "square_equality_substitution", "relation": "z1*z4=z2*z3",
                "sixth_form": "zero"}

    assert set(pair_names) == {"s1s2", "s3s4"}
    epsilon = -1 if cycle_coefficient > 0 else 1
    # The Laurent parameterization below assumes the relevant ratios are
    # nonzero.  Cover the four coordinate components of C=epsilon*D=0
    # separately so no endpoint is lost through division.
    singular_components = ((1, 3), (1, 4), (2, 3), (2, 4))
    singular_certificates = []
    for component in singular_components:
        singular_reduction = zero_edges(poly, edge_count, component)
        singular_certificates.append({
            "zero_edges": list(component),
            "nonnegative_residual": nonnegative_s_polynomial(
                singular_reduction, edge_count
            ),
        })
    substitutions = {
        w[4]: replacement(variables, (z[1], w[2]), (z[3],), epsilon),
        z[4]: replacement(variables, (w[1], z[2]), (w[3],), epsilon),
    }
    reduced = substitute_monomials(poly, substitutions)
    s = [poly_mul(poly_variable(z[i], variables), poly_variable(w[i], variables))
         for i in range(edge_count)]
    rho_plus_inverse = poly_add(
        poly_mul(s[3], {tuple(-x for x in next(iter(s[1]))): Fraction(1)}),
        poly_mul(s[1], {tuple(-x for x in next(iter(s[3]))): Fraction(1)}),
    )
    phase = poly_product([
        poly_variable(z[0], variables), poly_variable(z[0], variables),
        poly_variable(z[3], variables), poly_variable(w[1], variables),
        {tuple(-x for x in next(iter(poly_product([
            poly_variable(w[3], variables), poly_variable(z[1], variables)
        ], variables)))): Fraction(1)},
    ], variables)
    real_phase = poly_scale(poly_add(phase, poly_conjugate(phase, edge_count)),
                            Fraction(1, 2))
    phase_sign = 1 if cycle_coefficient > 0 else -1
    bracket = poly_add(poly_mul(s[0], rho_plus_inverse),
                       poly_scale(real_phase, 2 * phase_sign))
    expected = poly_mul(poly_mul(s[1], s[2]), bracket)
    ratio = proportional(reduced, expected)
    assert ratio is not None and ratio >= 0
    return {
        "type": "positive_phase_bound",
        "quartic_relation": f"z1*conj(z2)={epsilon:+d}*z3*conj(z4)",
        "sixth_prefactor": str(ratio),
        "sixth_bracket": (
            "s0*(rho+rho^-1)+2*Re(w^2)" if phase_sign > 0 else
            "s0*(rho+rho^-1)-2*Re(w^2)"
        ),
        "definitions": {"rho": "|z3/z1|^2", "w": "z0*(z3/z1)/|z3/z1|"},
        "inequalities": ["rho+rho^-1 >= 2", "|Re(w^2)| <= s0"],
        "singular_components": singular_certificates,
    }


def c4_certificate(poly, pattern, edge_count):
    variables = 2 * edge_count
    z = list(range(edge_count))
    w = list(range(edge_count, 2 * edge_count))
    pairs = ((0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3))
    pair_nonzero = [i for i in range(6) if pattern[i]]
    cycle_coefficient = pattern[6]
    if not cycle_coefficient:
        assert len(pair_nonzero) == 1
        pair = pairs[pair_nonzero[0]]
        branches = []
        for edge in pair:
            reduced = zero_edges(poly, edge_count, (edge,))
            assert not reduced
            branches.append({"zero_edge": edge, "sixth_form": "zero"})
        return {"type": "monomial_zero_branches", "branches": branches}

    coefficients = [pattern[i] for i in pair_nonzero]
    if len(pair_nonzero) == 2 and all(value == Fraction(1, 2)
                                      for value in coefficients):
        matching = {pairs[i] for i in pair_nonzero}
        data = {
            frozenset(((0, 2), (1, 3))): ((0, 2), (1, 3)),
            frozenset(((0, 3), (1, 2))): ((0, 3), (1, 2)),
            frozenset(((0, 1), (2, 3))): ((0, 1), (2, 3)),
        }
        (a, b), (c, d) = data[frozenset(matching)]
        sign = 1 if cycle_coefficient < 0 else -1
        substitutions = {
            z[b]: replacement(variables, (w[c], w[d]), (z[a],), sign),
            w[b]: replacement(variables, (z[c], z[d]), (w[a],), sign),
        }
        reduced = substitute_monomials(poly, substitutions)
        assert not reduced
        return {"type": "square_equality_substitution",
                "relation": f"z{a}*z{b}={sign:+d}*conj(z{c}*z{d})",
                "sixth_form": "zero"}

    # Four cross terms of weight 1/4.  With no extra matching monomial,
    # equality means s2=s0, s3=s1, and P=-s0*s1.
    extra = [i for i in pair_nonzero if pattern[i] == 1]
    if not extra:
        substitutions = {
            w[2]: replacement(variables, (z[0], w[0]), (z[2],)),
            z[3]: replacement(variables, (w[0], w[1]), (z[2],), -1),
            w[3]: replacement(variables, (z[1], z[2]), (w[0],), -1),
        }
        reduced = substitute_monomials(poly, substitutions)
        assert not reduced
        return {"type": "long_am_gm_equality_substitution",
                "relations": ["s2=s0", "s3=s1", "P=-s0*s1"],
                "sixth_form": "zero"}

    assert len(extra) == 1 and pairs[extra[0]] in ((0, 2), (1, 3))
    extra_pair = pairs[extra[0]]
    other_pair = (1, 3) if extra_pair == (0, 2) else (0, 2)
    # Equality in C + s_a*s_b +/- P >= s_a*s_b requires either
    # both edges a,b to vanish, or both opposite edges together with one
    # of a,b.  These are the irreducible coordinate components.
    components = (extra_pair,
                  (other_pair[0], other_pair[1], extra_pair[0]),
                  (other_pair[0], other_pair[1], extra_pair[1]))
    for component in components:
        assert not zero_edges(poly, edge_count, component)
    return {"type": "edge_collapse_components",
            "components": [{"zero_edges": list(component), "sixth_form": "zero"}
                           for component in components]}


def k4_certificate(poly, pattern, names, edge_count):
    cycle_index = next(i for i, value in enumerate(pattern)
                       if value == -2 and names[i].startswith("P"))
    cycle = names[cycle_index]
    variables = 2 * edge_count
    z = list(range(edge_count))
    w = list(range(edge_count, 2 * edge_count))
    substitutions_by_cycle = {
        "P0132": {
            w[5]: replacement(variables, (z[1], w[4]), (z[0],)),
            z[5]: replacement(variables, (w[1], z[4]), (w[0],)),
        },
        "P0213": {
            z[4]: replacement(variables, (z[2], z[3]), (z[1],)),
            w[4]: replacement(variables, (w[2], w[3]), (w[1],)),
        },
        "P0123": {
            z[5]: replacement(variables, (z[2], w[3]), (z[0],), -1),
            w[5]: replacement(variables, (w[2], z[3]), (w[0],), -1),
        },
    }
    reduced = substitute_monomials(poly, substitutions_by_cycle[cycle])
    assert not reduced
    relations = {
        "P0132": "z0*conj(z5)=z1*conj(z4)",
        "P0213": "z1*z4=z2*z3",
        "P0123": "z0*z5=-z2*conj(z3)",
    }
    return {"type": "square_equality_substitution", "relation": relations[cycle],
            "sixth_form": "zero"}


def graph_data(name, sparse_result, dense_by_name):
    if name == "C4":
        selected_rows, _, _, quotient_basis, _ = sparse.exact_quotient()
        rays = sparse_result["rays"]
        names = [f"s{i}s{j}" for i, j in sparse.PAIRS] + ["P0123"]
        patterns = [[Fraction(x) for x in ray["normalized_am_gm_pattern"]]
                    for ray in rays]
        return sparse.CYCLE, selected_rows, quotient_basis, rays, names, patterns
    edges = dense.GRAPH_EDGES[name]
    selected_rows, _, _, quotient_basis, _ = dense.exact_quotient(edges)
    graph = dense_by_name[name]
    rays = graph["rays"]
    patterns = [[Fraction(x) for x in ray["primitive_quartic_pattern"]]
                for ray in rays]
    return edges, selected_rows, quotient_basis, rays, graph["monomial_order"], patterns


def verify_graph(name, sparse_result, dense_by_name, seed):
    edges, selected_rows, quotient_basis, rays, quartic_names, patterns = graph_data(
        name, sparse_result, dense_by_name
    )
    raw, descriptors, samples, feature_rows, interpolation, validation = \
        independent_feature_system(name, edges, seed)
    symbolic = symbolic_features(edges, descriptors)
    sample_indices = interpolation + validation
    sixth_vectors = {
        index: sixth_minor_vector(samples[index][:len(edges)], edges, selected_rows)
        for index in sample_indices
    }
    functionals = [[
        sum(quotient_basis[j][r] * ray["ray"][j]
            for j in range(len(quotient_basis)))
        for r in range(14)
    ] for ray in rays]
    records = []
    for ray_index, (ray, pattern, functional) in enumerate(
            zip(rays, patterns, functionals)):
        evaluations = {
            index: sum(functional[r] * sixth_vectors[index][r]
                       for r in range(14))
            for index in sample_indices
        }
        matrix = [feature_rows[index] for index in interpolation]
        rhs = [evaluations[index] for index in interpolation]
        coefficients = fifth.solve_square(matrix, rhs)
        assert all(sum(feature_rows[index][j] * coefficients[j]
                       for j in range(len(coefficients))) == evaluations[index]
                   for index in validation)
        poly = combine_symbolic(coefficients, symbolic)
        if name == "paw":
            certificate = paw_certificate(poly, pattern, quartic_names, len(edges))
        elif name == "K4-e":
            certificate = k4e_certificate(poly, pattern, quartic_names, len(edges))
        elif name == "C4":
            certificate = c4_certificate(poly, pattern, len(edges))
        else:
            certificate = k4_certificate(poly, pattern, quartic_names, len(edges))
        records.append({
            "ray_index": ray_index,
            "ray": ray["ray"],
            "quartic_pattern": [str(x) for x in pattern],
            "sixth_coefficients": [str(x) for x in coefficients],
            "equality_certificate": certificate,
        })
    return {
        "graph": name,
        "edges": [list(edge) for edge in edges],
        "raw_invariant_basis_dimension": len(raw),
        "invariant_basis_rank": len(descriptors),
        "invariant_basis": [descriptor_name(item) for item in descriptors],
        "interpolation_samples": len(interpolation),
        "independent_validation_samples": len(validation),
        "arithmetic": "exact Gaussian rationals and exact Laurent polynomials",
        "rays": records,
    }


def verify_sixth_order(sparse_path, dense_path):
    sparse_result = json.loads(Path(sparse_path).read_text())
    dense_result = json.loads(Path(dense_path).read_text())
    dense_by_name = {graph["graph"]: graph for graph in dense_result["graphs"]}
    graphs = [verify_graph(name, sparse_result, dense_by_name, 20260720 + 1000 * i)
              for i, name in enumerate(("paw", "K4-e", "C4", "K4"))]
    return {
        "statement": (
            "for every n=4 support graph and every exact dual ray, the sixth "
            "dual form is nonnegative on the zero set of the quartic dual form"
        ),
        "consequence": (
            "at a commuting point, zero quadratic and quartic coefficients force "
            "the cubic and quintic coefficients to vanish and the sixth "
            "coefficient is inward or zero; the first unresolved term is order seven"
        ),
        "basis_completeness": (
            "every degree-six diagonal-gauge invariant is a union of directed "
            "cycles of types 2+2+2, 4+2, or 3+3"
        ),
        "graphs": graphs,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sparse-certificate", type=Path,
                        default=Path("results_quartic_cone_exact.json"))
    parser.add_argument("--dense-certificate", type=Path,
                        default=Path("results_quartic_dense_cone_exact.json"))
    parser.add_argument("--output", type=Path,
                        default=Path("results_sixth_order_exact.json"))
    args = parser.parse_args()
    result = verify_sixth_order(args.sparse_certificate, args.dense_certificate)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps({
        "output": str(args.output),
        "graphs": [{"graph": graph["graph"],
                    "rays": len(graph["rays"]),
                    "invariant_rank": graph["invariant_basis_rank"]}
                   for graph in result["graphs"]],
        "first_unresolved_order": 7,
    }, indent=2))


if __name__ == "__main__":
    main()
