#!/usr/bin/env python3
"""Exact fifth-order follow-up to the n=4 quartic cone certificates.

At a commuting permutation point, let a supporting functional have zero
quadratic outward variation.  The quartic cone certificates make its fourth
variation nonpositive.  This script verifies the next degeneracy statement:

    if the fourth variation is also zero, then the fifth variation is zero.

The only new graph calculations are the paw graph and K4-e.  Their fifth
forms are interpolated exactly from the Taylor series over Gaussian rationals;
diagonal-unitary gauge invariance shows that the displayed invariant bases are
complete.  For K4, the exact dual rays are invariant under permutation
inversion, which annihilates every odd Taylor coefficient, not just the fifth.

This is a local one-parameter result, not a proof of the global conjecture.
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

import moc_quartic_cone as sparse
import moc_quartic_dense_cone as dense


@dataclass(frozen=True)
class Gaussian:
    real: Fraction = Fraction(0)
    imag: Fraction = Fraction(0)

    def __add__(self, other: "Gaussian") -> "Gaussian":
        return Gaussian(self.real + other.real, self.imag + other.imag)

    def __neg__(self) -> "Gaussian":
        return Gaussian(-self.real, -self.imag)

    def __sub__(self, other: "Gaussian") -> "Gaussian":
        return self + (-other)

    def __mul__(self, other: "Gaussian") -> "Gaussian":
        return Gaussian(self.real * other.real - self.imag * other.imag,
                        self.real * other.imag + self.imag * other.real)

    def scale(self, value: Fraction) -> "Gaussian":
        return Gaussian(self.real * value, self.imag * value)

    def conjugate(self) -> "Gaussian":
        return Gaussian(self.real, -self.imag)


ZERO = Gaussian()
ONE = Gaussian(Fraction(1))


PAW_SAMPLES = (
    ((-1, 2), (2, -1), (0, 2), (1, 2)),
    ((-2, 2), (-2, 1), (0, 2), (-1, -1)),
    ((1, 2), (2, 1), (1, -1), (-1, -1)),
    ((2, 1), (-2, -2), (-1, 2), (-2, 0)),
)

K4_MINUS_EDGE_SAMPLES = (
    ((-1, 2), (-2, 0), (-2, 1), (1, 1), (1, -1)),
    ((-2, 1), (-2, 1), (1, 2), (-2, 1), (0, -1)),
    ((2, -2), (0, -2), (-2, -2), (2, -2), (1, -1)),
    ((1, -2), (2, -1), (1, 1), (2, -1), (0, -1)),
    ((-1, 1), (0, -2), (1, 2), (-2, -1), (0, -2)),
    ((0, 2), (1, 2), (-1, 0), (0, 2), (1, 2)),
    ((1, 2), (-2, 1), (-1, 1), (1, -1), (0, 2)),
    ((0, -2), (1, 2), (-2, -1), (2, 1), (0, 1)),
    ((-2, 1), (-2, 0), (2, 2), (2, 1), (-1, -1)),
    ((2, -1), (-2, -1), (2, 2), (-1, 1), (2, 0)),
)


def matrix_product(a, b):
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), ZERO)
             for j in range(len(b[0]))] for i in range(len(a))]


def convolution(a, b, order: int = 5):
    out = [ZERO for _ in range(order + 1)]
    for i in range(order + 1):
        for j in range(order + 1 - i):
            out[i + j] = out[i + j] + a[i] * b[j]
    return out


def unitary_series(k, order: int = 5):
    power = [[ONE if i == j else ZERO for j in range(4)] for i in range(4)]
    answer = []
    factorial = 1
    for r in range(order + 1):
        if r:
            power = matrix_product(power, k)
            factorial *= r
        answer.append([[entry.scale(Fraction(1, factorial)) for entry in row]
                       for row in power])
    return answer


def minor_series(u, i_set, j_set, order: int = 5):
    size = len(i_set)
    if size == 0:
        return [ONE] + [ZERO for _ in range(order)]
    out = [ZERO for _ in range(order + 1)]
    for permutation in itertools.permutations(range(size)):
        inversions = sum(permutation[i] > permutation[j]
                         for i in range(size) for j in range(i + 1, size))
        term = [ONE] + [ZERO for _ in range(order)]
        for i in range(size):
            entry = [u[r][i_set[i]][j_set[permutation[i]]]
                     for r in range(order + 1)]
            term = convolution(term, entry, order)
        if inversions % 2:
            term = [-entry for entry in term]
        out = [x + y for x, y in zip(out, term)]
    return out


def generator(edge_values, edges):
    k = [[ZERO for _ in range(4)] for _ in range(4)]
    for value, (i, j) in zip(edge_values, edges):
        k[i][j] = value
        k[j][i] = -value.conjugate()
    return k


def fifth_minor_vector(edge_values, edges, selected_rows):
    u = unitary_series(generator(edge_values, edges))
    answer = []
    for row in selected_rows:
        i_set, j_set = sparse.ROWS[row]
        determinant = minor_series(u, i_set, j_set)
        absolute_square = convolution(
            determinant, [entry.conjugate() for entry in determinant]
        )
        assert absolute_square[5].imag == 0
        answer.append(absolute_square[5].real)
    return answer


def squared_magnitudes(values):
    return [(value * value.conjugate()).real for value in values]


def triangle_real_part(k, triangle):
    i, j, ell = triangle
    return (k[i][j] * k[j][ell] * k[ell][i]).real


def invariant_features(values, edges, triangles):
    k = generator(values, edges)
    squared = squared_magnitudes(values)
    features = []
    names = []
    for triangle in triangles:
        t = triangle_real_part(k, triangle)
        label = "T" + "".join(str(i) for i in triangle)
        for edge, value in enumerate(squared):
            features.append(value * t)
            names.append(f"s{edge}{label}")
    return features, names


def solve_square(a, b):
    n = len(a)
    rows = [[Fraction(x) for x in row] + [Fraction(y)]
            for row, y in zip(a, b)]
    for column in range(n):
        pivot = next(i for i in range(column, n) if rows[i][column])
        rows[column], rows[pivot] = rows[pivot], rows[column]
        value = rows[column][column]
        rows[column] = [x / value for x in rows[column]]
        for i in range(n):
            if i != column and rows[i][column]:
                value = rows[i][column]
                rows[i] = [rows[i][j] - value * rows[column][j]
                           for j in range(n + 1)]
    return [rows[i][-1] for i in range(n)]


def as_gaussians(sample):
    return [Gaussian(Fraction(real), Fraction(imag)) for real, imag in sample]


def primitive_pattern(coefficients):
    if not any(coefficients):
        return tuple(0 for _ in coefficients)
    return dense.primitive_integer_vector(list(coefficients))


def paw_implication_certificate(quartic_pattern, fifth_pattern,
                                quartic_names, fifth_names):
    if not any(fifth_pattern):
        return {"type": "fifth_form_zero"}
    quartic_columns = [i for i, value in enumerate(quartic_pattern) if value]
    fifth_columns = [i for i, value in enumerate(fifth_pattern) if value]
    assert len(quartic_columns) == len(fifth_columns) == 1
    qname = quartic_names[quartic_columns[0]]
    fname = fifth_names[fifth_columns[0]]
    assert qname in {"s0s2", "s1s2"}
    assert fname == "s2T012"
    # If s_j*s_2=0, either s_2=0 or the triangle product T012
    # contains the vanished edge j.  In both cases s_2*T012=0.
    return {"type": "monomial_divisibility", "quartic_monomial": qname,
            "fifth_monomial": fname}


K4E_PLUS = (0, 0, 1, 0, -1, 0, -1, 0, 1, 0)
K4E_MINUS = (0, 0, -1, 0, -1, 0, 1, 0, 1, 0)


def k4e_implication_certificate(quartic_pattern, fifth_pattern,
                                quartic_names, fifth_names):
    if not any(fifth_pattern):
        return {"type": "fifth_form_zero"}
    normalized = tuple(fifth_pattern)
    signless = normalized if next(x for x in normalized if x) > 0 \
        else tuple(-x for x in normalized)
    cycle_column = quartic_names.index("P0213")
    cycle_coefficient = quartic_pattern[cycle_column]
    if cycle_coefficient == 2:
        allowed = K4E_PLUS
        relation = "A=-B"
    elif cycle_coefficient == -2:
        allowed = tuple(-x for x in K4E_MINUS)
        relation = "A=B"
    else:
        raise AssertionError("a nonzero fifth form must accompany an AM-GM equality")
    allowed_signless = allowed if next(x for x in allowed if x) > 0 \
        else tuple(-x for x in allowed)
    assert signless == allowed_signless
    # Put A=z1*conj(z2), B=z3*conj(z4).  The quartic forms are
    # |A+B|^2 and |A-B|^2.  Substitution of A=-B or A=B into the
    # displayed fifth pattern gives zero identically.
    return {"type": "am_gm_equality_substitution", "relation": relation,
            "A": "z1*conj(z2)", "B": "z3*conj(z4)",
            "fifth_invariant_order": fifth_names}


def verify_interpolated_graph(name, samples, triangles, graph_result):
    edges = dense.GRAPH_EDGES[name]
    selected_rows, _, _, quotient_basis, _ = dense.exact_quotient(edges)
    values = [as_gaussians(sample) for sample in samples]
    feature_rows = [invariant_features(value, edges, triangles)[0]
                    for value in values]
    feature_names = invariant_features(values[0], edges, triangles)[1]
    assert len(sparse.rref(feature_rows)[1]) == len(feature_names)
    fifth_vectors = [fifth_minor_vector(value, edges, selected_rows)
                     for value in values]
    quartic_names = graph_result["monomial_order"]
    records = []
    for ray_record in graph_result["rays"]:
        ray = ray_record["ray"]
        functional = [
            sum(quotient_basis[j][r] * ray[j] for j in range(len(quotient_basis)))
            for r in range(14)
        ]
        evaluations = [sum(functional[r] * vector[r] for r in range(14))
                       for vector in fifth_vectors]
        coefficients = solve_square(feature_rows, evaluations)
        fifth_pattern = primitive_pattern(coefficients)
        quartic_pattern = tuple(ray_record["primitive_quartic_pattern"])
        if name == "paw":
            implication = paw_implication_certificate(
                quartic_pattern, fifth_pattern, quartic_names, feature_names
            )
        else:
            implication = k4e_implication_certificate(
                quartic_pattern, fifth_pattern, quartic_names, feature_names
            )
        records.append({
            "ray": ray,
            "quartic_pattern": list(quartic_pattern),
            "fifth_coefficients": [str(x) for x in coefficients],
            "primitive_fifth_pattern": list(fifth_pattern),
            "quartic_zero_implies_fifth_zero": implication,
        })
    return {
        "graph": name,
        "invariant_basis": feature_names,
        "interpolation_samples": samples,
        "interpolation_rank": len(feature_names),
        "arithmetic": "exact Gaussian rationals",
        "rays": records,
    }


def verify_fifth_order() -> dict:
    dense_result = dense.verify_dense_cones()
    by_name = {graph["graph"]: graph for graph in dense_result["graphs"]}
    paw = verify_interpolated_graph(
        "paw", PAW_SAMPLES, ((0, 1, 2),), by_name["paw"]
    )
    k4e = verify_interpolated_graph(
        "K4-e", K4_MINUS_EDGE_SAMPLES, ((0, 1, 2), (0, 1, 3)),
        by_name["K4-e"]
    )
    assert by_name["K4"]["all_dual_rays_inversion_symmetric"]
    return {
        "statement": "for every n=4 active support graph, zero quadratic and quartic outward coefficients force the fifth coefficient to vanish",
        "interpolated_graphs": [paw, k4e],
        "K4_odd_order_certificate": {
            "all_dual_rays_inversion_symmetric": True,
            "argument": "minor-coordinate transposition sends the order-r Taylor vector to (-1)^r times itself, while permutation-column transposition sends sigma to sigma inverse",
            "conclusion": "every odd coefficient is annihilated",
        },
        "other_graphs": {
            "C4": "triangle-free, so no degree-five diagonal-gauge invariant exists",
            "at_most_three_edges": "contained in the n<=3, Givens, disjoint-edge, or triangle-free reductions",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path,
                        default=Path("results_fifth_order_exact.json"))
    args = parser.parse_args()
    result = verify_fifth_order()
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps({
        "output": str(args.output),
        "graphs": [{"graph": graph["graph"], "rays": len(graph["rays"]),
                    "invariant_basis_dimension": graph["interpolation_rank"]}
                   for graph in result["interpolated_graphs"]],
        "K4_all_odd_orders_vanish": True,
    }, indent=2))


if __name__ == "__main__":
    main()
