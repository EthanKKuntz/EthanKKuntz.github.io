#!/usr/bin/env python3
"""Boundary-focused MOC search around commuting (permutation) equality cases.

For random spectra and support direction, relabel b so the identity permutation
is the exposed polygon vertex, then test U=exp(i t H) across logarithmic t bins.
The second variation is necessarily a conic combination of transposition chords;
this search targets the first potentially dangerous higher-order behavior.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict
from pathlib import Path

import numpy as np
from scipy.linalg import expm

import moc_search as m


def boundary_survey(n: int, seed: int, samples: int) -> dict:
    rng = np.random.default_rng(seed)
    perms = m.permutations(n)
    bins = [(1e-3, 1e-2), (1e-2, 5e-2), (5e-2, 2e-1), (2e-1, 1.0)]
    records = [{"gaps": [], "best": None, "outside": 0} for _ in bins]
    quadratic_errors = []

    for sample in range(samples):
        a, b = m.normalize_spectra(
            rng.normal(size=n) + 1j * rng.normal(size=n),
            rng.normal(size=n) + 1j * rng.normal(size=n),
        )
        theta = rng.uniform(-math.pi, math.pi)
        vv = m.permutation_products(a, b, perms)
        sigma = perms[int(np.argmax(np.real(np.exp(-1j * theta) * vv)))]
        b = b[sigma]  # identity is now the exposed vertex

        h = m.hermitian_from_params(rng.normal(size=n * n), n)
        h -= np.trace(h) / n * np.eye(n)
        h /= max(1e-15, np.linalg.norm(h))
        k = 1j * h

        # Numerically check the exact second-variation identity once per 100 runs.
        if sample % 100 == 0:
            base = np.prod(a + b)
            predicted = 0j
            for i in range(n):
                for j in range(i + 1, n):
                    bp = b.copy()
                    bp[i], bp[j] = bp[j], bp[i]
                    predicted += 2 * abs(k[i, j]) ** 2 * (np.prod(a + bp) - base)
            eps = 2e-4
            zp = m.determinant_value(a, b, expm(eps * k))
            zm = m.determinant_value(a, b, expm(-eps * k))
            observed = (zp - 2 * base + zm) / eps**2
            quadratic_errors.append(abs(observed - predicted) / max(1e-12, abs(predicted)))

        jbin = sample % len(bins)
        lo, hi = bins[jbin]
        t = math.exp(rng.uniform(math.log(lo), math.log(hi)))
        u = expm(t * k)
        vv = m.permutation_products(a, b, perms)
        z = m.determinant_value(a, b, u)
        ngap, _, _ = m.normalized_gap(z, vv, theta)
        rec = records[jbin]
        rec["gaps"].append(ngap)
        rec["outside"] += int(ngap > 1e-10)
        if rec["best"] is None or ngap > rec["best"][0]:
            c = m.make_candidate(n, "near-permutation-boundary", seed, a, b, u, theta, perms)
            rec["best"] = (ngap, t, asdict(c))

    output_bins = []
    for (lo, hi), rec in zip(bins, records):
        arr = np.asarray(rec["gaps"])
        output_bins.append({
            "t_range": [lo, hi], "samples": len(arr), "outside_count": rec["outside"],
            "gap_quantiles": {str(q): float(np.quantile(arr, q)) for q in [0, .5, .9, .99, 1]},
            "best_t": rec["best"][1], "best": rec["best"][2],
        })
    return {"n": n, "seed": seed, "samples": samples, "bins": output_bins,
            "second_variation_relative_error_max": float(max(quadratic_errors)),
            "second_variation_relative_error_median": float(np.median(quadratic_errors))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dimensions", nargs="+", type=int, default=[4, 5, 6])
    ap.add_argument("--samples", type=int, default=12000)
    ap.add_argument("--seed", type=int, default=20260720)
    ap.add_argument("--output", type=Path, default=Path("results_boundary.json"))
    args = ap.parse_args()
    data = {"objective": "support gap from an exposed permutation vertex",
            "results": [boundary_survey(n, args.seed + n, args.samples) for n in args.dimensions]}
    args.output.write_text(json.dumps(data, indent=2))
    print(json.dumps({"output": str(args.output), "dimensions": args.dimensions,
                      "samples_each": args.samples}, indent=2))


if __name__ == "__main__":
    main()
